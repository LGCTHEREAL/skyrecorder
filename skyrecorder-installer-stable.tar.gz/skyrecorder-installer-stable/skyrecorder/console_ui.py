"""Console UI for SkyRecorder — used on Windows where GTK is unavailable."""

import logging
import signal
import sys
import threading
from collections.abc import Callable

logger = logging.getLogger(__name__)


class ConsoleUI:
    def __init__(
        self,
        on_start: Callable[[], None],
        on_stop: Callable[[], None],
        on_shutdown: Callable[[], None] | None = None,
        auto_start: bool = False,
    ):
        self._on_start = on_start
        self._on_stop = on_stop
        self._on_shutdown = on_shutdown
        self._auto_start = auto_start
        self._obs_ok = False
        self._recording = False
        self._song: tuple[str, str] | None = None
        self._done = threading.Event()

    def log(self, message: str, level: str = "INFO") -> None:
        name = level.upper()
        getattr(logger, level.lower(), logger.info)(message)

    def set_obs_status(self, connected: bool) -> None:
        self._obs_ok = connected

    def set_recording(self, active: bool) -> None:
        self._recording = active

    def set_song(self, artist: str, title: str) -> None:
        self._song = (artist, title)

    def clear_song(self) -> None:
        self._song = None

    def run(self) -> None:
        if self._auto_start:
            if sys.platform == "win32":
                signal.signal(signal.SIGINT, lambda s, f: self._handle_shutdown())
                signal.signal(signal.SIGTERM, lambda s, f: self._handle_shutdown())
            self._on_start()
        while not self._done.is_set():
            self._done.wait(timeout=1.0)

    def _handle_shutdown(self) -> None:
        if self._on_shutdown:
            self._on_shutdown()
        self._done.set()
