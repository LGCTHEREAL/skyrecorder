import re
from typing import Any


AD_INDICATORS = {
    "title": re.compile(
        r"(advert|sponsor|^ad\b|you might also like|listen now|play ad|commercial|promo|recommended)",
        re.IGNORECASE,
    ),
    "album": re.compile(
        r"(advert|sponsor|^ad\b|commercial|promo)",
        re.IGNORECASE,
    ),
}

AD_ARTIST_NAMES = frozenset({
    "spotify",
    "spotify advertising",
    "spotify ads",
    "advertisement",
    "unknown artist",
    "",
})

MAX_SONG_LENGTH_US = 120_000_000  # 120 seconds in microseconds
MIN_SONG_LENGTH_US = 8_000_000  # 8 seconds


def _get_text(value: Any) -> str:
    if isinstance(value, (list, tuple)) and len(value) > 0:
        return str(value[0])
    return str(value) if value else ""


def is_ad(metadata: dict) -> bool:
    title = _get_text(metadata.get("xesam:title", "")).lower()
    artist_list = metadata.get("xesam:artist", [])
    artist = _get_text(artist_list).lower() if artist_list else ""
    album = _get_text(metadata.get("xesam:album", "")).lower()
    length = metadata.get("mpris:length", 0)
    if length:
        length = int(length)
    track_id = (metadata.get("mpris:trackid") or "").lower()

    if artist in AD_ARTIST_NAMES:
        return True

    if "/ad/" in track_id or "/sponsor" in track_id or "/commercial" in track_id:
        return True

    if AD_INDICATORS["title"].search(title):
        return True

    if AD_INDICATORS["album"].search(album):
        return True

    if length and length < MAX_SONG_LENGTH_US:
        if not artist and not title:
            return True

    if length and length < MIN_SONG_LENGTH_US:
        return True

    return False
