from collections.abc import Callable
from typing import Any
from gi import require_version
require_version("Gtk", "4.0")
require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib, Gio, Pango, Gdk
import logging
import signal

logger = logging.getLogger(__name__)

CSS = """
window { background: #b0d4f1; }
.sky-header { background: linear-gradient(180deg, #6bb3d9, #87ceeb); border: none; box-shadow: 0 1px 4px rgba(0,0,0,0.1); }
.status-card { background: rgba(255,255,255,0.7); border-radius: 12px; padding: 16px; margin: 6px 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.status-label { color: #5a7a9a; font-size: 11px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 4px; }
.status-value { color: #2c3e50; font-size: 13px; }
.title-text { color: #ffffff; font-size: 15px; font-weight: 600; text-shadow: 0 1px 2px rgba(0,0,0,0.15); }
.btn-monitor { background: rgba(255,255,255,0.85); color: #2c3e50; font-weight: 700; border-radius: 24px; padding: 10px 32px; margin: 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
.btn-monitor:hover { background: rgba(255,255,255,1); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
.btn-stop { background: #ff6b6b; color: #fff; font-weight: 700; border-radius: 24px; padding: 10px 32px; margin: 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
.btn-stop:hover { background: #ee5a5a; }
"""


_FORMATS = [("mp3", "MP3 (VBR q0)"), ("wav", "WAV (PCM 24-bit)"), ("flac", "FLAC (lossless)")]


def _level_class(levelname: str) -> str:
    return {"WARNING": "log-warn", "ERROR": "log-error", "CRITICAL": "log-error"}.get(levelname, "log-info")


class AppUI:
    def __init__(self, on_start: Callable, on_stop: Callable, on_shutdown: Callable | None = None,
                 auto_start: bool = False, initial_formats: Any = ("mp3",),
                 on_format_change: Callable[[set], None] | None = None,
                 on_key_change: Callable[[str], None] | None = None):
        self._on_start = on_start
        self._on_stop = on_stop
        self._on_shutdown = on_shutdown
        self._auto_start = auto_start
        self._on_format_change = on_format_change
        self._on_key_change = on_key_change
        self._acoustid_key = ""
        self._acoustid_label: Gtk.Label | None = None
        self._fmts = {k for k, _ in _FORMATS if k in set(initial_formats or {"mp3"})}
        if not self._fmts:
            self._fmts = {"mp3"}
        self._running = False
        # Widgets only exist after "activate": logs/status set before that
        # (main.py logs exporter status before ui.run()) are buffered here.
        self._ready = False
        self._pending: list[tuple[str, str]] = []

        Adw.init()
        self._app = Adw.Application(
            application_id="com.skyrecorder.app",
            flags=Gio.ApplicationFlags.FLAGS_NONE,
        )
        self._app.connect("activate", self._on_activate)
        self._app.connect("shutdown", self._on_app_shutdown)

    def run(self):
        self._app.run(None)

    def _on_app_shutdown(self, app):
        if self._on_shutdown:
            self._on_shutdown()

    def _unix_signal_cb(self) -> bool:
        self._app.quit()
        return GLib.SOURCE_REMOVE

    def _on_activate(self, app):
        # Graceful shutdown on SIGTERM/SIGINT so queued exports get flushed
        # (on_shutdown → exporter.shutdown() must run before the loop dies).
        for sig in (signal.SIGTERM, signal.SIGINT):
            GLib.unix_signal_add(GLib.PRIORITY_HIGH, sig, self._unix_signal_cb)
        css = Gtk.CssProvider()
        css.load_from_string(CSS)
        display = Gdk.Display.get_default()
        if display:
            Gtk.StyleContext.add_provider_for_display(
                display, css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )

        win = Gtk.ApplicationWindow(
            application=app,
            title="Spotify → OBS",
            default_width=420,
            default_height=580,
            resizable=False,
        )

        header = Adw.HeaderBar(css_classes=["sky-header"])
        header.set_title_widget(Gtk.Label(label="Spotify → OBS", css_classes=["title-text"]))
        key_btn = Gtk.Button(icon_name="emblem-system-symbolic", tooltip_text="Clé API AcoustID")
        key_btn.connect("clicked", self._on_key_clicked)
        header.pack_start(key_btn)
        win.set_titlebar(header)
        self._win = win

        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # OBS Status
        self._obs_card = _status_card("OBS", main_box)
        self._obs_dot, self._obs_label = _status_row("Connection", "Disconnected", self._obs_card)
        self._rec_dot, self._rec_label = _status_row("Recording", "Idle", self._obs_card)
        self._key_dot, self._key_label = _status_row("AcoustID", "Not configured", self._obs_card)

        # Now Playing
        self._song_card = _status_card("Now Playing", main_box)
        self._song_label = Gtk.Label(label="No song playing", css_classes=["status-value"], xalign=0)
        self._song_label.set_ellipsize(Pango.EllipsizeMode.END)
        self._song_card.append(self._song_label)

        # Export formats (multi-selection)
        self._export_card = _status_card("Export", main_box)
        fmt_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        fmt_row.append(Gtk.Label(label="Formats", css_classes=["status-value"], xalign=0))
        self._fmt_buttons: dict[str, Gtk.ToggleButton] = {}
        for key, label in _FORMATS:
            btn = Gtk.ToggleButton(label=label, css_classes=["btn-monitor"])
            btn.connect("toggled", self._on_fmt_toggled)
            self._fmt_buttons[key] = btn
            fmt_row.append(btn)
        self._export_card.append(fmt_row)
        self._sync_fmt_buttons()

        self._acoustid_label = Gtk.Label(css_classes=["status-value"], xalign=0)
        self._export_card.append(self._acoustid_label)
        self._sync_acoustid_label()

        # Activity Log
        log_box = _status_card("Activity", main_box)
        self._log_buffer = Gtk.TextBuffer()
        tag_table = self._log_buffer.get_tag_table()
        for name, color in [("log-info", "#7a9bb5"), ("log-warn", "#e8a838"), ("log-error", "#e87461")]:
            tag = Gtk.TextTag.new(name)
            tag.set_property("foreground", color)
            tag.set_property("font", "Monospace 10")
            tag_table.add(tag)

        self._log_view = Gtk.TextView(
            buffer=self._log_buffer, editable=False, cursor_visible=False,
            wrap_mode=Gtk.WrapMode.WORD, vexpand=True, hexpand=True,
        )
        scrolled = Gtk.ScrolledWindow(
            child=self._log_view, vexpand=True, min_content_height=180,
        )
        scrolled.set_css_classes(["status-card"])
        log_box.append(scrolled)

        # Button
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, halign=Gtk.Align.CENTER)
        self._btn = Gtk.Button(label="Start Monitoring", css_classes=["btn-monitor"])
        self._btn.connect("clicked", self._on_btn_clicked)
        btn_box.append(self._btn)
        main_box.append(btn_box)

        win.set_child(main_box)
        win.present()
        self._ready = True
        for text, cls in self._pending:
            GLib.idle_add(self._append_log, text, cls)
        self._pending.clear()
        self.log("App started")
        if self._auto_start:
            GLib.idle_add(self._trigger_start)

    def _on_btn_clicked(self, btn):
        if self._running:
            self._running = False
            btn.set_label("Start Monitoring")
            btn.set_css_classes(["btn-monitor"])
            self._on_stop()
            self.set_recording(False)
            self.log("Monitoring stopped")
        else:
            self._running = True
            btn.set_label("Stop Monitoring")
            btn.set_css_classes(["btn-stop"])
            try:
                self._on_start()
            except Exception:
                self.log("Failed to start monitoring", "ERROR")
                self._running = False
                btn.set_label("Start Monitoring")
                btn.set_css_classes(["btn-monitor"])
                return
            self.log("Monitoring started")

    def _sync_fmt_buttons(self) -> None:
        for key, btn in self._fmt_buttons.items():
            btn.set_active(key in self._fmts)

    def _on_fmt_toggled(self, _btn) -> None:
        fmts = {k for k, b in self._fmt_buttons.items() if b.get_active()}
        if not fmts:
            # garder au moins un format actif
            self._sync_fmt_buttons()
            return
        self._fmts = fmts
        if self._on_format_change:
            self._on_format_change(fmts)
        self.log(f"Formats d'export: {', '.join(sorted(fmts))}")

    def set_acoustid(self, key: str) -> None:
        self._acoustid_key = (key or "").strip()
        self._sync_acoustid_label()

    def _sync_acoustid_label(self) -> None:
        if self._acoustid_key:
            hint = self._acoustid_key[:4] + "…" if len(self._acoustid_key) > 4 else "…"
            text, active = f"Actif ({hint})", True
        else:
            text, active = "Non configuré", False
        if getattr(self, "_acoustid_label", None) is not None:
            self._acoustid_label.set_text(f"AcoustID: {text}")
        if getattr(self, "_key_label", None) is not None:
            GLib.idle_add(self._set_dot_value, self._key_dot, self._key_label, text, active)

    def _on_key_clicked(self, _btn) -> None:
        dialog = Gtk.Dialog(title="Clé API AcoustID", transient_for=self._win, modal=True)
        dialog.add_button("Annuler", Gtk.ResponseType.CANCEL)
        dialog.add_button("Enregistrer", Gtk.ResponseType.OK)
        box = dialog.get_content_area()
        box.set_spacing(8)
        box.append(Gtk.Label(
            label="Collez votre clé API AcoustID (gratuite) :\nhttps://acoustid.org/new-application",
            wrap=True, xalign=0))
        entry = Gtk.Entry(placeholder_text="Clé API…", hexpand=True)
        box.append(entry)
        dialog.connect("response", self._on_key_response, entry)
        dialog.present()

    def _on_key_response(self, dialog, resp, entry) -> None:
        key = entry.get_text().strip() if resp == Gtk.ResponseType.OK else None
        dialog.destroy()
        if key is None:
            return
        self.set_acoustid(key)
        if self._on_key_change:
            self._on_key_change(key)
        self.log("Clé AcoustID enregistrée" if key else "Clé AcoustID effacée")

    def _trigger_start(self):
        self._on_btn_clicked(self._btn)
        return False

    # ── Public API ──

    def log(self, message: str, level: str = "INFO"):
        name = level.upper()
        cls = _level_class(name)
        text = f"[{name}] {message}"
        if not self._ready:
            self._pending.append((text, cls))
            return
        GLib.idle_add(self._append_log, text, cls)

    def set_obs_status(self, connected: bool):
        if not self._ready:
            return
        GLib.idle_add(self._set_dot_value, self._obs_dot, self._obs_label,
                       "Connected" if connected else "Disconnected", connected)

    def set_recording(self, active: bool):
        if not self._ready:
            return
        GLib.idle_add(self._set_dot_value, self._rec_dot, self._rec_label,
                       "Recording" if active else "Idle", active)

    def set_song(self, artist: str, title: str):
        if not self._ready:
            return
        text = f"{artist} — {title}" if artist else title
        GLib.idle_add(self._song_label.set_label, text)

    def clear_song(self):
        if not self._ready:
            return
        GLib.idle_add(self._song_label.set_label, "No song playing")

    def _append_log(self, text: str, cls: str):
        end = self._log_buffer.get_end_iter()
        self._log_buffer.insert_with_tags_by_name(end, text + "\n", cls)
        adj = self._log_view.get_vadjustment()
        if adj:
            adj.set_value(adj.get_upper() - adj.get_page_size())
        return False

    def _set_dot_value(self, dot: Gtk.Label, label: Gtk.Label, text: str, active: bool):
        color = "#6eb5e8" if active else "#b0c4d8"
        dot.set_markup(f'<span foreground="{color}">●</span>')
        label.set_text(text)
        return False


def _status_card(title: str, parent: Gtk.Box) -> Gtk.Box:
    card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, css_classes=["status-card"])
    lbl = Gtk.Label(label=title.upper(), css_classes=["status-label"], xalign=0)
    card.append(lbl)
    parent.append(card)
    return card


def _status_row(label_text: str, initial: str, parent: Gtk.Box) -> tuple[Gtk.Label, Gtk.Label]:
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    dot = Gtk.Label()
    dot.set_markup('<span foreground="#b0c4d8">●</span>')
    lbl = Gtk.Label(label=label_text, css_classes=["status-value"], xalign=0)
    val = Gtk.Label(label=initial, css_classes=["status-value"], xalign=1, hexpand=True)
    row.append(dot)
    row.append(lbl)
    row.append(val)
    parent.append(row)
    return dot, val
