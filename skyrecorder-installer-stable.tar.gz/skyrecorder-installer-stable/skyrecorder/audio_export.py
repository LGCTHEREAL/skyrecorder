"""
Automatic MP3 export: converts finished recordings to 320 kbps MP3s with
full metadata (album, track #, year, genre) and embedded cover art.

Metadata chain (best first, first hit wins for album fields):
  1. AcoustID / Chromaprint fingerprint  — exact match, needs free API key
  2. MusicBrainz artist+title search     — zero config, great indie coverage
  3. Spotify Web API search              — used when spotify_config.json exists

Cover art: MusicBrainz Cover Art Archive, then Spotify, iTunes, Deezer.

All work runs on a background queue so encoding never blocks recording.
"""

import json
import logging
import os
import queue
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

import requests

logger = logging.getLogger(__name__)

APP_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = APP_DIR / "skyrecorder_config.json"
SPOTIFY_CONFIG_PATH = APP_DIR / "spotify_config.json"

MB_URL = "https://musicbrainz.org/ws/2"
CA_URL = "https://coverartarchive.org/release"
CA_RG_URL = "https://coverartarchive.org/release-group"
ACOUSTID_URL = "https://api.acoustid.org/v2/lookup"
SPOTIFY_TOKEN_URL = "https://accounts.spotify.com/api/token"
SPOTIFY_API_URL = "https://api.spotify.com/v1"

USER_AGENT = "SkyRecorder/1.0 (local desktop recorder)"
_MB_MIN_INTERVAL = 1.05  # MusicBrainz rate limit: 1 req/s

_INVALID = '<>:"/\\|?*'

# Export formats. Cover art is only embedded for containers that support it
# (MP3/ID3, FLAC/Vorbis comments) — WAV has no metadata or picture block.
FORMATS = {
    "mp3": {"ext": ".mp3", "label": "MP3 (VBR q0, up to 320 kbps)"},
    "wav": {"ext": ".wav", "label": "WAV (PCM 24-bit, lossless)"},
    "flac": {"ext": ".flac", "label": "FLAC (lossless)"},
}
_FORMAT_KEYS = list(FORMATS)


def _sanitize(name: str) -> str:
    return "".join(c if c.isprintable() and c not in _INVALID else "_" for c in name).strip() or "_"


def _image_ext(data: bytes) -> str:
    """Devine l'extension d'une image d'après ses octets magiques.

    ffmpeg choisit le démultiplexeur d'image selon l'extension du fichier :
    une extension générique (".img") fait échouer l'encodage.
    """
    if data[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    return ".jpg"


def _write_cover(data: bytes) -> str | None:
    """Écrit la pochette dans un fichier temporaire, convertie en JPEG si besoin.

    MP3 (ID3/APIC) et FLAC n'acceptent que JPEG et PNG comme pochette : on
    normalise tout le reste en JPEG. Retourne le chemin, ou None si la
    conversion échoue.
    """
    ext = _image_ext(data)
    fd, raw = tempfile.mkstemp(suffix=ext)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    if ext == ".jpg":
        return raw

    fd, out = tempfile.mkstemp(suffix=".jpg")
    os.close(fd)
    r = subprocess.run(
        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
         "-i", raw, "-frames:v", "1", out],
        capture_output=True, text=True, timeout=60,
    )
    try:
        os.unlink(raw)
    except OSError:
        pass
    if r.returncode != 0:
        try:
            os.unlink(out)
        except OSError:
            pass
        return None
    return out


def _load_json(path: Path) -> dict:
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception:
        logger.debug("Could not read %s", path)
    return {}


def _mb_get(path: str, params: dict | None = None) -> Any:
    """GET from MusicBrainz, respecting the 1 req/s rate limit.

    Retries 429/503 (MB throttles bursts) and transient network errors.
    """
    last_error: Exception | None = None
    for attempt in range(4):
        now = time.monotonic()
        delta = now - _mb_get.last
        if delta < _MB_MIN_INTERVAL:
            time.sleep(_MB_MIN_INTERVAL - delta)
        _mb_get.last = time.monotonic()
        try:
            r = requests.get(
                f"{MB_URL}/{path}",
                params={"fmt": "json", **(params or {})},
                headers={"User-Agent": USER_AGENT},
                timeout=15,
            )
        except requests.RequestException as e:
            last_error = e
            time.sleep(2 ** (attempt + 1))
            continue
        if r.status_code in (429, 503):
            last_error = RuntimeError(f"HTTP {r.status_code} from MusicBrainz")
            time.sleep(2 ** (attempt + 1))
            continue
        r.raise_for_status()
        return r.json()
    raise last_error if last_error else RuntimeError("MusicBrainz request failed")


_mb_get.last = 0.0


class AudioExporter:
    def __init__(
        self,
        log_cb: Any = None,
        enabled: bool = True,
        cover: bool = True,
        fmts: Any = ("mp3",),
    ):
        self._log_cb = log_cb
        self._cover = cover
        self._queue: queue.Queue = queue.Queue()
        self._thread: threading.Thread | None = None

        self.requested = enabled
        self._fmts = self._normalise(fmts)
        self._ffmpeg_ok = _ffmpeg_supports(self._fmts)
        self.enabled = bool(enabled and self._ffmpeg_ok)

        self._fpcalc = shutil.which("fpcalc")
        self._acoustid_key = str(_load_json(CONFIG_PATH).get("acoustid_api_key") or "").strip()
        self._acoustid_key_warned = False

        spotify = _load_json(SPOTIFY_CONFIG_PATH)
        self._spotify_id = str(spotify.get("client_id") or "")
        self._spotify_secret = str(spotify.get("client_secret") or "")
        self._spotify_token: str | None = None
        self._spotify_token_at = 0.0

        # NOTE: no log_cb calls in __init__ — the UI may not exist yet.

    @staticmethod
    def _normalise(fmts: Any) -> frozenset:
        """Accepte un format ou une liste -> ensemble de formats valides."""
        if isinstance(fmts, str):
            fmts = (fmts,)
        out = set()
        for f in fmts or ():
            f = str(f).strip().lower()
            if f in FORMATS:
                out.add(f)
        return frozenset(out) or frozenset({"mp3"})

    @property
    def fmts(self) -> frozenset:
        return self._fmts

    def set_formats(self, fmts: Any) -> frozenset:
        """Change les formats d'export a chaud (UI). Retourne l'ensemble actif."""
        new = self._normalise(fmts)
        if new == self._fmts:
            return self._fmts
        self._fmts = new
        self._ffmpeg_ok = _ffmpeg_supports(new)
        self.enabled = bool(self.requested and self._ffmpeg_ok)
        self._log(f"Formats d'export: {', '.join(sorted(new))}", "INFO")
        return self._fmts

    def reload_key(self) -> str:
        """Relit la clé AcoustID depuis le fichier de config. Retourne la clé."""
        self._acoustid_key = str(_load_json(CONFIG_PATH).get("acoustid_api_key") or "").strip()
        self._acoustid_key_warned = False
        return self._acoustid_key

    # ── Public API ──

    def status(self) -> tuple[bool, str]:
        if not self.requested:
            return False, "Export disabled (--no-mp3)"
        if not shutil.which("ffmpeg"):
            return False, "ffmpeg not found — export disabled (install ffmpeg)"
        if not self._ffmpeg_ok:
            return False, "ffmpeg lacks libmp3lame — MP3 export disabled"
        chain = []
        if self._acoustid_key and self._fpcalc:
            chain.append("AcoustID")
        chain.append("MusicBrainz")
        if self._spotify_id and self._spotify_secret:
            chain.append("Spotify")
        fmt_list = " + ".join(f.upper() for f in sorted(self._fmts))
        msg = f"Export ready ({fmt_list}): metadata via " + " → ".join(chain)
        if self._cover:
            msg += ", cover art (MusicBrainz → iTunes → Deezer)"
        if self.requested and not self._acoustid_key:
            msg += " (add acoustid_api_key to skyrecorder_config.json for fingerprint matching)"
        return True, msg

    def enqueue(self, path: Path | str, artist: str, title: str) -> None:
        if not self.enabled:
            return
        if self._thread is None:
            self._thread = threading.Thread(target=self._worker, daemon=True, name="mp3-export")
            self._thread.start()
        self._queue.put((Path(path), artist or "", title or ""))
        self._log(f"Queued for MP3 export: {Path(path).name}", "INFO")

    def shutdown(self, timeout: float = 300.0) -> None:
        if self._thread is None:
            return
        self._queue.put(None)
        self._thread.join(timeout)
        if self._thread.is_alive():
            self._log("MP3 export still running in background", "WARNING")
        self._thread = None

    # ── Worker ──

    def _worker(self) -> None:
        while True:
            item = self._queue.get()
            if item is None:
                break
            path, artist, title = item
            try:
                self._process(path, artist, title)
            except Exception as e:
                self._log(f"MP3 export failed for {path.name}: {e}", "ERROR")
                logger.exception("MP3 export failed")

    def _process(self, path: Path, artist: str, title: str) -> None:
        if not path.exists():
            self._log(f"MP3 export skipped (file missing): {path.name}", "WARNING")
            return

        meta = self._lookup(artist, title, path)
        tags = {
            "title": title or str(meta.get("title") or ""),
            "artist": artist or str(meta.get("artist") or ""),
        }
        for k in ("album", "album_artist", "track", "disc", "date", "genre"):
            if meta.get(k):
                tags[k] = str(meta[k])

        cover_file: str | None = None
        if self._cover:
            cover_bytes = self._fetch_cover(meta)
            if cover_bytes:
                cover_file = _write_cover(cover_bytes)

        for fmt in sorted(self._fmts):
            out = self._output_path(path, artist, title, fmt)
            tmp = out.with_name(out.name + ".part" + out.suffix)
            try:
                self._encode(path, tmp, tags, cover_file, fmt)
                os.replace(tmp, out)
            finally:
                if tmp.exists():
                    try:
                        tmp.unlink()
                    except OSError:
                        pass
            src = meta.get("_source", "basic tags")
            self._log(f"{fmt.upper()} exported ({src}): {out.name}", "INFO")

        if cover_file:
            try:
                os.unlink(cover_file)
            except OSError:
                pass

    def _encode(self, src: Path, dst: Path, tags: dict, cover_file: str | None, fmt: str) -> None:
        cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(src)]
        # WAV has no container for tags or pictures — skip both for it.
        embed = fmt in ("mp3", "flac")
        if cover_file and embed:
            cmd += ["-i", cover_file]
        cmd += ["-map", "0:a:0"]
        if cover_file and embed:
            cmd += ["-map", "1:v:0", "-disposition:v", "attached_pic"]
        if fmt == "mp3":
            # VBR quality 0 = best LAME encoding (up to 320 kbps, transparent for
            # most sources). CBR 320k re-padded every frame with useless data.
            cmd += ["-c:a", "libmp3lame", "-q:a", "0", "-id3v2_version", "3"]
        elif fmt == "wav":
            # 24-bit PCM: keeps headroom the 16-bit source cannot represent.
            cmd += ["-c:a", "pcm_s24le"]
        else:
            # FLAC level 8 = smallest lossless file; quality is identical at any level.
            cmd += ["-c:a", "flac", "-compression_level", "8"]
        if embed:
            for key, val in tags.items():
                if val:
                    cmd += ["-metadata", f"{key}={val}"]
        cmd.append(str(dst))
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if r.returncode != 0:
            raise RuntimeError(f"ffmpeg failed: {(r.stderr or '').strip()[-300:]}")

    def _output_path(self, path: Path, artist: str, title: str, fmt: str) -> Path:
        ext = FORMATS[fmt]["ext"]
        safe = " - ".join(_sanitize(p) for p in (artist, title) if p) or path.stem
        candidate = path.parent / f"{safe}{ext}"
        n = 2
        while candidate.exists():
            candidate = path.parent / f"{safe} ({n}){ext}"
            n += 1
        return candidate

    # ── Metadata chain ──

    def _lookup(self, artist: str, title: str, path: Path) -> dict:
        meta: dict = {"_source": "basic tags"}

        # Tier 1: AcoustID fingerprint (exact match)
        if self._acoustid_key and self._fpcalc:
            try:
                mbid = self._acoustid_lookup(path)
                if mbid:
                    detail = self._mb_recording_detail(mbid)
                    if detail:
                        meta = detail
                        meta["_source"] = "AcoustID + MusicBrainz"
            except Exception as e:
                if "invalid API key" in str(e) and not self._acoustid_key_warned:
                    self._acoustid_key_warned = True
                    self._log(
                        "Cle AcoustID invalide — metadata via MusicBrainz a la place. "
                        "Entrez une cle valide (bouton cles en haut).",
                        "WARNING",
                    )
                logger.debug("AcoustID tier failed: %s", e)

        # Tier 2: MusicBrainz search
        if meta.get("_source") == "basic tags":
            try:
                detail = self._mb_search(artist, title)
                if detail:
                    meta = detail
                    meta["_source"] = "MusicBrainz"
            except Exception as e:
                logger.debug("MusicBrainz tier failed: %s", e)

        # Tier 3: Spotify (also enriches when available)
        if (meta.get("_source") == "basic tags" or not meta.get("album")) and \
                self._spotify_id and self._spotify_secret:
            try:
                sp = self._spotify_search(artist, title)
                if sp:
                    if meta.get("_source") == "basic tags":
                        meta = sp
                        meta["_source"] = "Spotify"
                    else:
                        for k, v in sp.items():
                            if not k.startswith("_") and not meta.get(k):
                                meta[k] = v
                        if sp.get("_cover_url"):
                            meta["_cover_url"] = sp["_cover_url"]
            except Exception as e:
                logger.debug("Spotify tier failed: %s", e)

        return meta

    # ── AcoustID / Chromaprint ──

    def _acoustid_lookup(self, path: Path) -> str | None:
        r = subprocess.run(
            [self._fpcalc, "-json", "-length", "120", str(path)],
            capture_output=True, text=True, timeout=60,
        )
        if r.returncode != 0:
            return None
        data = json.loads(r.stdout)
        fp = data.get("fingerprint")
        dur = data.get("duration")
        if not fp or not dur:
            return None

        r = requests.post(
            ACOUSTID_URL,
            data={
                "client": self._acoustid_key,
                "format": "json",
                "meta": "recordings",
                "fingerprint": fp,
                "duration": int(dur),
            },
            timeout=15,
        )
        if r.status_code == 400:
            try:
                err = r.json().get("error") or {}
            except Exception:
                err = {}
            raise RuntimeError("AcoustID: %s" % (err.get("message") or "HTTP 400"))
        r.raise_for_status()
        results = r.json().get("results", [])
        best_mbid, best_score = None, 0.0
        for res in results:
            score = float(res.get("score") or 0)
            for rec in res.get("recordings", []):
                if rec.get("id") and score > best_score:
                    best_mbid, best_score = rec["id"], score
        if best_mbid and best_score >= 0.8:
            return best_mbid
        return None

    # ── MusicBrainz ──

    def _mb_search(self, artist: str, title: str) -> dict | None:
        if not artist and not title:
            return None
        query = " AND ".join(
            f'{field}:"{value}"'
            for field, value in (("recording", title), ("artist", artist)) if value
        )
        # status:official drops bootlegs/live tapes from the candidate pool.
        # MB relevance order is unreliable (score ties shuffle between calls:
        # the original studio recording can rank anywhere), so pull the whole
        # pool and rank by first-release-date ourselves.
        q_used = query + " AND status:official"
        data = _mb_get("recording", {"query": q_used, "limit": 100})
        recordings = data.get("recordings", [])
        if not recordings:
            # very rare: only unofficial recordings exist for this name
            q_used = query
            data = _mb_get("recording", {"query": q_used, "limit": 100})
            recordings = data.get("recordings", [])
        if data.get("count", 0) > len(recordings):
            more = _mb_get(
                "recording",
                {"query": q_used, "limit": 100, "offset": len(recordings)},
            )
            recordings.extend(more.get("recordings", []))
        if not recordings:
            return None

        # The original precedes reissues, live versions, karaoke and covers,
        # so the earliest first-release-date wins. Stable sort keeps MB
        # relevance order within ties; prefer audio over music videos.
        recordings.sort(key=lambda r: (
            r.get("first-release-date") or "9999", bool(r.get("video"))
        ))
        rec = recordings[0]

        detail = _mb_get(f"recording/{rec['id']}", {"inc": "artists+releases"})
        releases = detail.get("releases", [])
        official = sorted(
            (r for r in releases if r.get("status") == "Official"),
            key=lambda r: r.get("date") or "9999",
        )
        meta: dict = {
            "title": detail.get("title") or "",
            "artist": _artist_credit(detail.get("artist-credit")),
        }
        if official:
            meta.update(self._mb_release_track(official[0]["id"], detail.get("id") or rec["id"]))
        elif rec.get("first-release-date"):
            # unofficial-only recording: keep title/artist/year, no album
            meta["date"] = rec["first-release-date"][:4]
        return meta

    def _mb_recording_detail(self, mbid: str) -> dict | None:
        data = _mb_get(f"recording/{mbid}", {"inc": "artists+releases+release-groups"})
        releases = sorted(
            data.get("releases", []),
            key=lambda r: (r.get("status") != "Official", r.get("date") or "9999"),
        )
        meta: dict = {
            "title": data.get("title") or "",
            "artist": _artist_credit(data.get("artist-credit")),
        }
        if releases:
            meta.update(self._mb_release_track(releases[0]["id"], mbid))
            if not meta.get("date") and releases[0].get("date"):
                meta["date"] = releases[0]["date"][:4]
        return meta if (meta.get("album") or meta.get("title")) else None

    def _mb_release_track(self, release_id: str, recording_id: str | None) -> dict:
        """Fetch a release to get album title, track/disc numbers and date."""
        out: dict = {"_release_mbid": release_id}
        data = _mb_get(f"release/{release_id}", {"inc": "recordings+artist-credits+release-groups"})
        out["album"] = data.get("title") or ""
        out["album_artist"] = _artist_credit(data.get("artist-credit"))
        if not out["album_artist"]:
            out.pop("album_artist")
        rg = (data.get("release-group") or {})
        if rg.get("id"):
            out["_release_group_mbid"] = rg["id"]
        date = rg.get("first-release-date") or data.get("date") or ""
        if date:
            out["date"] = date[:4]
        for medium in data.get("media", []):
            for track in medium.get("tracks", []):
                if recording_id and track.get("recording", {}).get("id") == recording_id:
                    out["track"] = track.get("position") or ""
                    out["disc"] = medium.get("position") or 1
                    return out
        return out

    # ── Spotify ──

    def _spotify_token_get(self) -> str | None:
        if self._spotify_token and time.monotonic() - self._spotify_token_at < 3000:
            return self._spotify_token
        r = requests.post(
            SPOTIFY_TOKEN_URL,
            data={
                "grant_type": "client_credentials",
                "client_id": self._spotify_id,
                "client_secret": self._spotify_secret,
            },
            timeout=15,
        )
        if r.status_code != 200:
            return None
        self._spotify_token = r.json().get("access_token")
        self._spotify_token_at = time.monotonic()
        return self._spotify_token

    def _spotify_search(self, artist: str, title: str) -> dict | None:
        token = self._spotify_token_get()
        if not token:
            return None
        parts = []
        if artist:
            parts.append(f'artist:"{artist}"')
        if title:
            parts.append(f'track:"{title}"')
        r = requests.get(
            f"{SPOTIFY_API_URL}/search",
            params={"q": " ".join(parts), "type": "track", "limit": 1},
            headers={"Authorization": f"Bearer {token}"},
            timeout=15,
        )
        if r.status_code != 200:
            return None
        items = (r.json().get("tracks") or {}).get("items") or []
        if not items:
            return None
        item = items[0]
        album = item.get("album") or {}
        meta: dict = {
            "title": item.get("name") or "",
            "artist": ", ".join(a.get("name", "") for a in item.get("artists", [])),
            "album": album.get("name") or "",
            "album_artist": ", ".join(a.get("name", "") for a in album.get("artists", [])),
        }
        if item.get("track_number"):
            meta["track"] = item["track_number"]
        if item.get("disc_number"):
            meta["disc"] = item["disc_number"]
        if album.get("release_date"):
            meta["date"] = album["release_date"][:4]
        if album.get("images"):
            meta["_cover_url"] = album["images"][0].get("url")
        # Genre from the artist (one extra call, worth it)
        artists = item.get("artists") or []
        if artists and artists[0].get("id"):
            g = requests.get(
                f"{SPOTIFY_API_URL}/artists/{artists[0]['id']}",
                headers={"Authorization": f"Bearer {token}"},
                timeout=15,
            )
            if g.status_code == 200:
                genres = g.json().get("genres") or []
                if genres:
                    meta["genre"] = genres[0].replace("-", " ").title()
        return meta

    # ── Cover art ──

    def _fetch_cover(self, meta: dict) -> bytes | None:
        # 1. MusicBrainz Cover Art Archive (official artwork)
        release_mbid = meta.get("_release_mbid")
        if release_mbid:
            art = self._caa_front(f"{CA_URL}/{release_mbid}")
            if art:
                return art
            # many releases lack edition art; the release-group usually has it
        rg_mbid = meta.get("_release_group_mbid")
        if rg_mbid:
            art = self._caa_front(f"{CA_RG_URL}/{rg_mbid}")
            if art:
                return art
        # 2. Spotify album image
        url = meta.get("_cover_url")
        if url:
            art = self._download_image(url)
            if art:
                return art
        # 3. iTunes Search API (gratuit, sans cle)
        art = self._itunes_cover(meta.get("artist", ""), meta.get("title", ""))
        if art:
            return art
        # 4. Deezer API (gratuit, sans cle)
        return self._deezer_cover(meta.get("artist", ""), meta.get("title", ""))

    @staticmethod
    def _download_image(url: str) -> bytes | None:
        try:
            r = requests.get(url, timeout=15)
            if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image/"):
                return r.content
        except requests.RequestException:
            pass
        return None

    def _itunes_cover(self, artist: str, title: str) -> bytes | None:
        """iTunes Search API — gratuit, sans cle, bonne couverture."""
        if not artist and not title:
            return None
        try:
            r = requests.get(
                "https://itunes.apple.com/search",
                params={"term": f"{artist} {title}".strip(), "entity": "song", "limit": 1},
                headers={"User-Agent": USER_AGENT},
                timeout=15,
            )
            if r.status_code != 200:
                return None
            items = r.json().get("results") or []
            if not items:
                return None
            url = items[0].get("artworkUrl100")
            if not url:
                return None
            # 100x100 -> 600x600 pour une meilleure resolution
            return self._download_image(url.replace("100x100bb", "600x600bb"))
        except requests.RequestException:
            return None

    def _deezer_cover(self, artist: str, title: str) -> bytes | None:
        """Deezer API — gratuit, sans cle, cover_xl haute resolution."""
        if not artist and not title:
            return None
        try:
            r = requests.get(
                "https://api.deezer.com/search",
                params={"q": f'artist:"{artist}" track:"{title}"', "limit": 1},
                headers={"User-Agent": USER_AGENT},
                timeout=15,
            )
            if r.status_code != 200:
                return None
            items = r.json().get("data") or []
            if not items:
                return None
            album = items[0].get("album") or {}
            for key in ("cover_xl", "cover_big", "cover_medium", "cover"):
                url = album.get(key)
                if url:
                    art = self._download_image(url)
                    if art:
                        return art
        except requests.RequestException:
            pass
        return None

    @staticmethod
    def _caa_front(base: str) -> bytes | None:
        for size in ("front-500", "front-250", "front"):
            try:
                r = requests.get(
                    f"{base}/{size}",
                    headers={"User-Agent": USER_AGENT},
                    timeout=15,
                )
                if r.status_code == 200 and r.headers.get("Content-Type", "").startswith("image/"):
                    return r.content
            except requests.RequestException:
                continue
        return None

    # ── Misc ──

    def _log(self, msg: str, level: str = "INFO") -> None:
        if self._log_cb:
            try:
                self._log_cb(msg, level)
            except Exception:
                pass
        getattr(logger, level.lower(), logger.info)("%s", msg)


def _artist_credit(credit: Any) -> str:
    if not credit:
        return ""
    if isinstance(credit, str):
        return credit
    names = []
    for part in credit:
        if isinstance(part, dict):
            name = part.get("name", "")
            if part.get("joinphrase"):
                name += part["joinphrase"]
            names.append(name)
    return "".join(names).strip()


def _ffmpeg_has_lame(ffmpeg: str) -> bool:
    try:
        r = subprocess.run(
            [ffmpeg, "-hide_banner", "-encoders"],
            capture_output=True, text=True, timeout=10,
        )
        return "libmp3lame" in (r.stdout + r.stderr)
    except Exception:
        return False


def _ffmpeg_supports(fmts: Any) -> bool:
    """True when the ffmpeg on PATH can encode every requested format."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return False
    fmts = fmts if isinstance(fmts, (set, frozenset, list, tuple)) else (fmts,)
    for fmt in fmts:
        if fmt == "mp3" and not _ffmpeg_has_lame(ffmpeg):
            return False
    # pcm_s24le and flac are compiled into every ffmpeg build OBS/distros ship
    return True
