import logging
import subprocess
import time
from pathlib import Path

from obsws_python import ReqClient

logger = logging.getLogger(__name__)


class OBSError(Exception):
    pass


class OBSController:
    def __init__(
        self,
        host: str = "localhost",
        port: int = 4455,
        password: str = "",
        min_record_secs: float = 15.0,
        exporter: object | None = None,
    ):
        self._host = host
        self._port = port
        self._password = password
        self._min_record_secs = min_record_secs
        self._exporter = exporter
        self._client: ReqClient | None = None
        self._record_start: float | None = None
        self._last_file_start: float | None = None
        self._current_artist: str = ""
        self._current_title: str = ""
        self._record_artist: str = ""
        self._record_title: str = ""
        self._paused: bool = False

    def connect(self) -> None:
        if self._client is not None:
            return
        try:
            self._client = ReqClient(
                host=self._host,
                port=self._port,
                password=self._password,
                timeout=3,
            )
            logger.info("Connected to OBS WebSocket at %s:%s", self._host, self._port)
        except Exception as e:
            self._client = None
            raise OBSError(
                f"Cannot connect to OBS at {self._host}:{self._port}. "
                f"Error: {e}"
            )

    def _is_recording(self) -> bool:
        if self._client is None:
            return False
        try:
            r = self._client.get_record_status()
            return r.output_active
        except Exception:
            self._client = None
            return False

    def start_recording(self) -> None:
        try:
            self.connect()
            if self._paused:
                self.resume_recording()
            if self._is_recording():
                logger.debug("OBS already recording — skipping start")
                return
            self._client.start_record()
            self._record_start = time.monotonic()
            self._last_file_start = time.time()
            self._record_artist = self._current_artist
            self._record_title = self._current_title
            self._paused = False
            logger.info("OBS: recording started — artist=%r title=%r", self._record_artist, self._record_title)
        except OBSError:
            raise
        except Exception as e:
            logger.error("Failed to start recording: %s", e)

    def pause_recording(self) -> None:
        try:
            self.connect()
            if not self._is_recording() or self._paused:
                return
            self._client.pause_record()
            self._paused = True
            logger.info("OBS: recording paused")
        except Exception as e:
            logger.warning("Failed to pause recording: %s", e)

    def resume_recording(self) -> None:
        if not self._paused:
            return
        try:
            self.connect()
            self._client.resume_record()
            self._paused = False
            logger.info("OBS: recording resumed")
        except Exception as e:
            logger.warning("Failed to resume recording: %s", e)

    def set_track(self, artist: str, title: str) -> None:
        self._current_artist = artist
        self._current_title = title
        logger.debug("Track set: %s — %s", artist, title)

    def stop_recording(self, artist: str = "", title: str = "") -> None:
        elapsed = (
            time.monotonic() - self._record_start
            if self._record_start is not None
            else float("inf")
        )
        self._record_start = None
        file_window = self._last_file_start
        self._last_file_start = None
        track_artist = artist or self._record_artist or ""
        track_title = title or self._record_title or ""
        logger.debug("stop_recording: record_artist=%r record_title=%r file_window=%r elapsed=%.1f",
                     self._record_artist, self._record_title, file_window, elapsed)
        if artist or title:
            logger.debug("stop_recording: explicit artist/title provided: %r %r", artist, title)

        try:
            self.connect()
            if self._paused:
                try:
                    self._client.resume_record()
                except Exception as e:
                    logger.debug("resume before stop: %s", e)
                self._paused = False
            try:
                self._client.stop_record()
            except Exception as e:
                # peut-etre deja arrete — on continue pour traiter le fichier
                logger.debug("stop_record: %s", e)
            self._wait_stopped()
            logger.info("OBS: recording stopped")
            final_path: Path | None = None
            if track_artist or track_title:
                final_path = self._rename_last_recording(track_artist, track_title, file_window)
            else:
                logger.debug("Skipping rename: no artist or title available")
            if elapsed < self._min_record_secs and file_window is not None:
                self._delete_last_recording(elapsed, file_window)
                final_path = None
            if final_path is not None and self._exporter is not None:
                self._exporter.enqueue(final_path, track_artist, track_title)
        except OBSError:
            raise
        except Exception as e:
            logger.error("Failed to stop recording: %s", e)

    def _wait_stopped(self, timeout: float = 5.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if not self._is_recording():
                return
            time.sleep(0.1)
        logger.warning("Timed out waiting for OBS recording to stop")

    def _find_last_recording(self, since: float) -> Path | None:
        if self._client is None:
            return None
        try:
            record_dir = self._client.get_record_directory().record_directory
        except Exception as e:
            logger.warning("Cannot get OBS record directory: %s", e)
            return None

        video_exts = {".mp4", ".mkv", ".mov", ".avi", ".flv", ".ts"}
        now = time.time()
        candidates = sorted(
            [
                f for f in Path(record_dir).iterdir()
                if f.suffix.lower() in video_exts
                and f.stat().st_mtime >= since - 4
                and f.stat().st_mtime <= now + 5
            ],
            key=lambda f: f.stat().st_mtime,
            reverse=True,
        )
        return candidates[0] if candidates else None

    def _rename_last_recording(self, artist: str, title: str, since: float | None) -> Path | None:
        logger.debug("_rename_last_recording: artist=%r title=%r since=%r", artist, title, since)
        if since is None:
            logger.debug("Skipping rename: since is None")
            return None
        filepath = self._find_last_recording(since)
        logger.debug("_find_last_recording(%r) → %r", since, filepath)
        if filepath is None:
            logger.warning("No recording file found to rename")
            return None
        suffix = filepath.suffix
        safe = " - ".join(
            _sanitize_filename(p) for p in (artist, title) if p
        )
        logger.debug("Safe filename: %r", safe)
        if not safe:
            logger.debug("Skipping rename: safe is empty")
            return filepath
        new_name = filepath.with_name(safe + suffix)
        n = 2
        while new_name.exists():
            new_name = filepath.with_name(f"{safe} ({n}){suffix}")
            n += 1
        try:
            filepath.rename(new_name)
            logger.info("Renamed recording: %s → %s", filepath.name, new_name.name)
            return new_name
        except Exception as e:
            logger.error("Failed to rename %s: %s", filepath.name, e)
            return filepath

    def _delete_last_recording(self, elapsed: float, since: float) -> None:
        filepath = self._find_last_recording(since)
        if filepath is None:
            logger.warning("No video files found in OBS record directory (since %.0f)", since)
            return

        duration = _get_media_duration_secs(str(filepath))
        logger.info(
            "Recording too short (%.1fs / min %.1fs) — deleting: %s (%.1fs)",
            elapsed,
            self._min_record_secs,
            filepath.name,
            duration,
        )
        try:
            filepath.unlink(missing_ok=True)
            logger.info("Deleted: %s", filepath.name)
        except Exception as e:
            logger.error("Failed to delete %s: %s", filepath.name, e)

    def disconnect(self) -> None:
        if self._client is not None:
            try:
                self._client.disconnect()
            except Exception:
                pass
            self._client = None


def _sanitize_filename(name: str) -> str:
    return "".join(c if c.isprintable() and c not in '<>:"/\\|?*' else "_" for c in name).strip() or "_"

def _get_media_duration_secs(filepath: str) -> float:
    try:
        r = subprocess.run(
            [
                "ffprobe", "-v", "error",
                "-show_entries", "format=duration",
                "-of", "default=noprint_wrappers=1:nokey=1",
                filepath,
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0 and r.stdout.strip():
            return float(r.stdout.strip())
    except Exception:
        pass
    return 0.0
