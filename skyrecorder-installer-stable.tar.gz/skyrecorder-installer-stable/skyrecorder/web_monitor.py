"""
Web API monitor for Spotify — used on Windows where D-Bus is not available.
Same interface as monitor.py (SpotifyMonitor).
"""

import json
import logging
import re
import time
import webbrowser
from collections.abc import Callable
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, parse_qs

import requests

logger = logging.getLogger(__name__)

CONFIG_PATH = Path(__file__).parent.parent / "spotify_config.json"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API_BASE = "https://api.spotify.com/v1"
AUTH_URL = "https://accounts.spotify.com/authorize"
REDIRECT_URI = "http://localhost:8888/callback"
SCOPES = "user-read-playback-state user-read-currently-playing"


class _OAuthServer:
    def __init__(self) -> None:
        self.auth_code: str | None = None

    class Handler(BaseHTTPRequestHandler):
        server_ref: "_OAuthServer" = None  # type: ignore

        def do_GET(self) -> None:
            params = parse_qs(self.path.split("?")[-1])
            code = params.get("code", [None])[0]
            if code:
                self.server_ref.auth_code = code
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"<html><body><h1>Authorized!</h1><p>Close this window.</p></body></html>")
            else:
                self.send_response(400)
                self.end_headers()

        def log_message(self, fmt: str, *args: Any) -> None:
            pass

    def get_code(self, auth_url: str, timeout: int = 120) -> str | None:
        self.Handler.server_ref = self
        server = HTTPServer(("127.0.0.1", 8888), self.Handler)
        server.timeout = timeout
        webbrowser.open(auth_url)
        logger.info("OAuth: waiting for callback on http://localhost:8888/callback")
        while server.timeout > 0:
            server.handle_request()
            if self.auth_code:
                server.server_close()
                return self.auth_code
        server.server_close()
        return None


class _Credentials:
    def __init__(self) -> None:
        self.client_id: str = ""
        self.client_secret: str = ""
        self.refresh_token: str = ""

    def load(self) -> None:
        if not CONFIG_PATH.exists():
            return
        data = json.loads(CONFIG_PATH.read_text())
        self.client_id = data.get("client_id", "")
        self.client_secret = data.get("client_secret", "")
        self.refresh_token = data.get("refresh_token", "")

    def save(self) -> None:
        CONFIG_PATH.write_text(json.dumps({
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "refresh_token": self.refresh_token,
        }, indent=2))

    @property
    def ready(self) -> bool:
        return bool(self.client_id and self.client_secret and self.refresh_token)


class WebMonitor:
    def __init__(
        self,
        on_song_start: Callable[[], None],
        on_stop: Callable[[], None],
        on_track: Callable[[str, str], None] | None = None,
        log_cb: Callable[[str, str], None] | None = None,
        poll_interval: int = 2,
    ):
        self._on_song_start = on_song_start
        self._on_stop = on_stop
        self._on_track = on_track
        self._log_cb = log_cb
        self._poll_interval = poll_interval
        self._creds = _Credentials()
        self._access_token: str | None = None
        self._last_track_id: str | None = None
        self._last_was_ad = False
        self._recording = False
        self._restart_pending = False
        self._poll_source: object | None = None
        self._stopped = False

    def start(self) -> None:
        if self._poll_source is not None:
            return

        self._creds.load()
        if not self._creds.ready:
            self._log("Spotify API credentials needed — starting setup", "WARNING")
            if not self._do_setup():
                self._log("Spotify setup failed", "ERROR")
                return

        self._log("Web API monitor started (poll every %ds)", "INFO", self._poll_interval)
        self._stopped = False
        self._poll_source = True  # marker that we're running
        import threading
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def disconnect(self) -> None:
        self._stopped = True
        self._poll_source = None
        self._recording = False
        self._restart_pending = False

    def _log(self, msg: str, level: str = "INFO", *args: Any) -> None:
        if self._log_cb:
            self._log_cb(msg % args if args else msg, level)
        getattr(logger, level.lower(), logger.info)(msg, *args)

    def _refresh_token(self) -> str | None:
        resp = requests.post(TOKEN_URL, data={
            "grant_type": "refresh_token",
            "refresh_token": self._creds.refresh_token,
            "client_id": self._creds.client_id,
            "client_secret": self._creds.client_secret,
        })
        if resp.status_code != 200:
            self._log("Token refresh failed: %s", "ERROR", resp.text[:200])
            return None
        return resp.json().get("access_token")

    def _get_token(self) -> str | None:
        if self._access_token:
            return self._access_token
        self._access_token = self._refresh_token()
        return self._access_token

    def _poll_api(self) -> dict | None:
        token = self._get_token()
        if token is None:
            return None
        try:
            resp = requests.get(
                f"{API_BASE}/me/player/currently-playing",
                headers={"Authorization": f"Bearer {token}"},
                timeout=5,
            )
        except requests.RequestException as e:
            self._log("API request failed: %s", "WARNING", e)
            self._access_token = None
            return None

        if resp.status_code == 401:
            self._access_token = None
            return None
        if resp.status_code == 204:
            return None
        if resp.status_code != 200:
            self._log("API error %s", "WARNING", resp.status_code)
            return None
        return resp.json()

    def _api_to_metadata(self, data: dict) -> dict | None:
        """Convert Spotify API response to the same metadata format as MPRIS."""
        item = data.get("item")
        if not item:
            return None
        artists = [a.get("name", "") for a in item.get("artists", [])]
        return {
            "mpris:trackid": item.get("id") or item.get("uri") or "",
            "xesam:title": item.get("name") or "",
            "xesam:artist": artists,
            "mpris:length": (item.get("duration_ms") or 0) * 1000,
            "mpris:artists": artists,
        }

    def _is_ad_api(self, data: dict) -> bool:
        item = data.get("item")
        if not item:
            return True
        if data.get("currently_playing_type") == "ad":
            return True
        if item.get("type") == "ad":
            return True
        name = (item.get("name") or "").lower()
        artists = [a.get("name", "").lower() for a in item.get("artists", [])]
        if "spotify" in artists or "spotify advertising" in artists:
            return True
        if re.search(r"(advert|sponsor|^ad\b)", name, re.IGNORECASE):
            return True
        return False

    def _run_loop(self) -> None:
        while not self._stopped:
            try:
                data = self._poll_api()
                if data is None:
                    time.sleep(self._poll_interval)
                    continue

                is_playing = data.get("is_playing", False)
                is_ad_track = self._is_ad_api(data)

                metadata = self._api_to_metadata(data)
                if metadata is None or not metadata.get("mpris:trackid"):
                    time.sleep(self._poll_interval)
                    continue

                track_id = metadata["mpris:trackid"]
                artist = ", ".join(metadata.get("xesam:artist", []))
                title = metadata.get("xesam:title", "") or ""
                track_changed = track_id != self._last_track_id

                if track_changed:
                    self._last_track_id = track_id
                    self._last_was_ad = is_ad_track
                    if self._on_track:
                        self._on_track(artist, title)
                    if is_ad_track:
                        self._log("Ad detected: %s — %s", "WARNING", artist, title)
                    else:
                        self._log("Track: %s — %s", "INFO", artist, title)

                if is_ad_track:
                    if self._recording:
                        self._recording = False
                        self._restart_pending = False
                        self._on_stop()
                    time.sleep(self._poll_interval)
                    continue

                if track_changed:
                    if self._recording:
                        self._restart_pending = True
                        self._recording = False
                        self._on_stop()
                    elif is_playing:
                        self._on_song_start()
                        self._recording = True
                    time.sleep(self._poll_interval)
                    continue

                if not is_playing and self._recording:
                    self._recording = False
                    self._restart_pending = False
                    self._on_stop()
                elif is_playing and not self._recording and not self._last_was_ad:
                    self._on_song_start()
                    self._recording = True

                if self._restart_pending and not self._last_was_ad:
                    self._restart_pending = False
                    self._on_song_start()
                    self._recording = True

            except Exception as e:
                self._log("Monitor error: %s", "ERROR", e)

            time.sleep(self._poll_interval)

    def _do_setup(self) -> bool:
        print()
        print("  ============================================")
        print("     SkyRecorder — Spotify API Setup")
        print("  ============================================")
        print()
        print("  1. Go to https://developer.spotify.com/dashboard/")
        print("  2. Click 'Create App'")
        print("  3. Name: SkyRecorder, redirect URI: http://localhost:8888/callback")
        print("  4. Save, then copy Client ID and Client Secret")
        print()
        self._creds.client_id = input("  Client ID: ").strip()
        self._creds.client_secret = input("  Client Secret: ").strip()
        if not self._creds.client_id or not self._creds.client_secret:
            print("  [ERROR] Client ID and Secret required")
            return False
        self._creds.save()

        params = urlencode({
            "client_id": self._creds.client_id,
            "response_type": "code",
            "redirect_uri": REDIRECT_URI,
            "scope": SCOPES,
        })
        auth_url = f"{AUTH_URL}?{params}"
        server = _OAuthServer()
        code = server.get_code(auth_url)
        if not code:
            print("  [ERROR] Authorization failed")
            return False

        resp = requests.post(TOKEN_URL, data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": REDIRECT_URI,
            "client_id": self._creds.client_id,
            "client_secret": self._creds.client_secret,
        })
        if resp.status_code != 200:
            print(f"  [ERROR] Token exchange failed: {resp.text[:200]}")
            return False

        tokens = resp.json()
        self._creds.refresh_token = tokens.get("refresh_token", "")
        if not self._creds.refresh_token:
            print(f"  [ERROR] No refresh_token: {tokens}")
            return False
        self._creds.save()
        print("  Spotify authorized successfully!")
        return True
