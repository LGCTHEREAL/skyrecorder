import logging
import time
from collections.abc import Callable

import gi

gi.require_version("GLib", "2.0")
gi.require_version("Gio", "2.0")
from gi.repository import GLib, Gio

from skyrecorder.ad_detector import is_ad

logger = logging.getLogger(__name__)

MPRIS_PATH = "/org/mpris/MediaPlayer2"
MPRIS_IFACE = "org.mpris.MediaPlayer2.Player"
PROPS_IFACE = "org.freedesktop.DBus.Properties"
SPOTIFY_PREFIX = "org.mpris.MediaPlayer2.spotify"
_STALL_SECS = 4.0  # position figee >= ce delai = pause reelle


class SpotifyMonitor:
    def __init__(
        self,
        on_song_start: Callable[[], None],
        on_stop: Callable[[], None],
        on_track: Callable[[str, str], None] | None = None,
        on_pause: Callable[[], None] | None = None,
        on_resume: Callable[[], None] | None = None,
        log_cb: Callable[[str, str], None] | None = None,
        poll_interval: int = 2,
    ):
        self._on_song_start = on_song_start
        self._on_stop = on_stop
        self._on_track = on_track
        self._on_pause = on_pause
        self._on_resume = on_resume
        self._log_cb = log_cb
        self._poll_interval = poll_interval
        self._recording = False
        self._paused = False
        self._last_track_id: str | None = None
        self._last_was_ad = False
        self._restart_pending = False
        self._busy = False
        self._spotify_name: str | None = None
        self._playback_status: str = "Stopped"
        self._initialised = False
        self._last_position: int | None = None
        self._pos_stable_since: float = 0.0

        self._connection: Gio.DBusConnection | None = None
        self._sub_id: int | None = None
        self._poll_source: int | None = None
        self._name_watch_id: int | None = None

    # ── Public API ──

    def start(self) -> None:
        if self._poll_source is not None:
            self._log("Monitor already started", "WARNING")
            return
        try:
            self._connection = Gio.bus_get_sync(Gio.BusType.SESSION)
        except GLib.Error as e:
            self._log("Cannot connect to session bus: %s" % e, "ERROR")
            return

        self._spotify_name = self._find_spotify()
        if self._spotify_name is not None:
            self._log("Spotify detected: %s" % self._spotify_name, "INFO")
            self._subscribe()
        else:
            self._log("Spotify not found on D-Bus — waiting for it to appear", "WARNING")

        self._name_watch_id = Gio.bus_watch_name(
            Gio.BusType.SESSION,
            SPOTIFY_PREFIX,
            Gio.BusNameWatcherFlags.NONE,
            self._on_name_appeared,
            self._on_name_vanished,
        )

        self._poll_source = GLib.timeout_add(self._poll_interval * 1000, self._poll)
        self._log("Spotify monitor started", "INFO")

    def disconnect(self) -> None:
        if self._poll_source is not None:
            GLib.source_remove(self._poll_source)
            self._poll_source = None
        if self._name_watch_id is not None:
            Gio.bus_unwatch_name(self._name_watch_id)
            self._name_watch_id = None
        if self._sub_id is not None and self._connection is not None:
            self._connection.signal_unsubscribe(self._sub_id)
            self._sub_id = None
        self._recording = False
        self._paused = False
        self._restart_pending = False
        self._initialised = False
        self._last_position = None

    # ── Bus name watching ──

    def _find_spotify(self) -> str | None:
        if self._connection is None:
            return None
        try:
            result = self._connection.call_sync(
                "org.freedesktop.DBus",
                "/org/freedesktop/DBus",
                "org.freedesktop.DBus",
                "ListNames",
                None,
                None,
                Gio.DBusCallFlags.NONE,
                -1,
                None,
            )
            names: list[str] = result.unpack()[0]
        except Exception as e:
            self._log("Cannot list D-Bus names: %s" % e, "ERROR")
            return None
        hits = sorted(n for n in names if n.startswith(SPOTIFY_PREFIX))
        return hits[0] if hits else None

    def _on_name_appeared(self, _connection: Gio.DBusConnection, name: str, _owner: str) -> None:
        self._log("Spotify appeared on D-Bus: %s" % name, "INFO")
        self._spotify_name = name
        self._subscribe()

    def _on_name_vanished(self, _connection: Gio.DBusConnection, name: str) -> None:
        self._log("Spotify vanished from D-Bus", "INFO")
        self._spotify_name = None
        self._last_track_id = None
        self._last_was_ad = False

    # ── Signal subscription ──

    def _subscribe(self) -> None:
        if self._connection is None:
            return
        if self._sub_id is not None:
            return
        sub = self._connection.signal_subscribe(
            SPOTIFY_PREFIX,
            PROPS_IFACE,
            "PropertiesChanged",
            MPRIS_PATH,
            None,
            Gio.DBusSignalFlags.NONE,
            self._on_properties_changed,
        )
        if sub != 0:
            self._sub_id = sub
            self._log("Subscribed to MPRIS signals", "INFO")
        else:
            self._log("Failed to subscribe to signals", "ERROR")

    # ── Logging ──

    def _log(self, msg: str, level: str = "INFO") -> None:
        if self._log_cb:
            if level == "ERROR":
                self._log_cb(msg, "ERROR")
            elif level == "WARNING":
                self._log_cb(msg, "WARNING")
            else:
                self._log_cb(msg, "INFO")
        getattr(logger, level.lower(), logger.info)("%s", msg)

    # ── Signal handler ──

    def _on_properties_changed(
        self,
        _connection: Gio.DBusConnection,
        _sender_name: str,
        _object_path: str,
        _interface_name: str,
        _signal_name: str,
        params: GLib.Variant,
    ) -> None:
        try:
            if not self._is_spotify_sender(_sender_name):
                return
            if self._busy:
                return
            self._busy = True
            body = params.unpack()
            iface = body[0]
            changed = body[1]
            if iface != MPRIS_IFACE:
                return
            metadata = changed.get("Metadata")
            playback_status = changed.get("PlaybackStatus")
            if metadata is not None:
                self._on_metadata(metadata)
            if playback_status is not None:
                self._on_playback_status(playback_status)
        except Exception:
            self._log("Error in D-Bus signal handler", "ERROR")
        finally:
            self._busy = False

    def _is_spotify_sender(self, sender: str | None) -> bool:
        if sender is None:
            return False
        if self._spotify_name and sender == self._spotify_name:
            return True
        try:
            result = self._connection.call_sync(
                "org.freedesktop.DBus",
                "/org/freedesktop/DBus",
                "org.freedesktop.DBus",
                "GetNameOwner",
                GLib.Variant.new_tuple(GLib.Variant("s", SPOTIFY_PREFIX)),
                GLib.VariantType.new("(s)"),
                Gio.DBusCallFlags.NONE,
                -1,
                None,
            )
            owner = result.unpack()[0]
            logger.debug("Spotify sender check: %s vs owner %s", sender, owner)
            if sender == owner:
                self._spotify_name = sender
                return True
        except Exception as exc:
            logger.warning("Cannot verify Spotify sender: %s", exc)
        return False

    # ── Track / status handlers ──

    def _on_metadata(self, metadata: dict) -> None:
        track_id = (metadata.get("mpris:trackid") or "").strip()
        if not track_id or track_id == self._last_track_id:
            return
        self._last_track_id = track_id

        artist = _get_artist(metadata)
        title = (metadata.get("xesam:title") or "") or ""

        if self._on_track:
            self._on_track(artist, title)

        if is_ad(metadata):
            self._log("Ad detected — stopping: %s — %s" % (artist, title), "WARNING")
            self._last_was_ad = True
            self._restart_pending = False
            if self._recording:
                self._do_stop()
            return

        self._last_was_ad = False
        self._log("Track: %s — %s" % (artist, title), "INFO")

        if self._recording:
            self._restart_pending = True
            self._do_stop()
        elif not self._initialised:
            # Premiere detection au lancement : ne pas enregistrer tout de suite
            # (Spotify est peut-etre en pause sur un vieux morceau).
            # On attend un changement de track ou un statut "Playing".
            self._initialised = True
            if self._playback_status == "Playing":
                self._on_song_start()
                self._recording = True
        else:
            # Nouveau track en cours de route -> on enregistre dans tous les cas
            # (le statut MPRIS du flatpak n'est pas fiable, reste 'Paused' meme en lecture)
            self._on_song_start()
            self._recording = True

    def _on_playback_status(self, status: str) -> None:
        self._playback_status = status
        if status == "Stopped":
            if self._recording:
                self._log("Playback stopped", "INFO")
                self._do_stop()
        elif status == "Paused":
            # On n'agit pas ici : on attend que Position reste fige
            # (_STALL_SECS) pour confirmer une vraie pause — le statut
            # du flatpak Spotify a deja ete vu incoherent.
            pass
        elif status == "Playing" and self._recording and self._paused:
            self._log("Playback resumed — unpausing recording", "INFO")
            self._paused = False
            if self._on_resume:
                self._on_resume()
        elif status == "Playing" and not self._recording and self._last_track_id is not None and not self._last_was_ad:
            self._log("Playback resumed — restarting recording", "INFO")
            self._on_song_start()
            self._recording = True

    def _do_stop(self) -> None:
        self._recording = False
        self._paused = False
        self._on_stop()
        if self._restart_pending:
            self._restart_pending = False
            GLib.idle_add(self._delayed_restart)

    def _delayed_restart(self) -> bool:
        if self._last_was_ad:
            self._log("Delayed restart skipped (last was ad)", "DEBUG")
            return False
        if self._recording:
            self._log("Delayed restart skipped (already recording)", "DEBUG")
            return False
        self._on_song_start()
        self._recording = True
        return False

    # ── Position-based pause detection ──

    def _on_position(self, pos: int) -> None:
        """Position MPRIS (microsecondes) : source fiable pour pause/reprise."""
        now = time.monotonic()
        if self._last_position is None:
            # Premier echantillon : simple reference, aucune action
            self._last_position = pos
            self._pos_stable_since = now
            return
        if pos != self._last_position:
            self._last_position = pos
            self._pos_stable_since = now
            if self._recording and self._paused:
                self._paused = False
                self._log("Playback position moving — resuming recording", "INFO")
                if self._on_resume:
                    self._on_resume()
            elif (
                not self._recording
                and self._initialised
                and not self._restart_pending
                and not self._last_was_ad
                and self._last_track_id is not None
            ):
                self._log("Playback position moving — starting recording", "INFO")
                self._on_song_start()
                self._recording = True
            return
        if (
            self._recording
            and not self._paused
            and not self._restart_pending
            and now - self._pos_stable_since >= _STALL_SECS
        ):
            self._paused = True
            self._log("Playback position stalled — pausing recording", "INFO")
            if self._on_pause:
                self._on_pause()

    # ── Polling (fallback only) ──

    def _poll(self) -> bool:
        try:
            if self._restart_pending:
                return True
            if self._sub_id is None and self._spotify_name is not None:
                self._subscribe()
            if self._connection is not None and self._spotify_name is not None:
                self._poll_metadata()
        except Exception:
            self._log("Error in poll", "ERROR")
        return True

    def _poll_metadata(self) -> None:
        if self._busy:
            return
        try:
            result = self._connection.call_sync(
                self._spotify_name,
                MPRIS_PATH,
                PROPS_IFACE,
                "GetAll",
                GLib.Variant.new_tuple(GLib.Variant("s", MPRIS_IFACE)),
                GLib.VariantType.new("(a{sv})"),
                Gio.DBusCallFlags.NONE,
                -1,
                None,
            )
            props = result.unpack()[0]
            metadata = props.get("Metadata")
            status = props.get("PlaybackStatus")
            position = props.get("Position")
            if metadata is not None:
                self._on_metadata(metadata)
            if status is not None:
                self._on_playback_status(status)
            if isinstance(position, int):
                self._on_position(position)
        except GLib.GError as e:
            if "AccessDenied" not in str(e) and "NameHasNoOwner" not in str(e):
                self._log("Poll metadata error: %s" % e, "ERROR")


def _get_artist(metadata: dict) -> str:
    artist_list = metadata.get("xesam:artist")
    if isinstance(artist_list, (list, tuple)) and len(artist_list) > 0:
        return str(artist_list[0])
    return str(artist_list) if artist_list else ""
