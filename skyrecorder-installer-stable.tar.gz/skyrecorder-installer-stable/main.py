#!/usr/bin/env python3
import argparse
import logging
import sys

_IS_WINDOWS = sys.platform == "win32"

from skyrecorder.obs_controller import OBSController, OBSError
from skyrecorder.audio_export import AudioExporter

if _IS_WINDOWS:
    from skyrecorder.web_monitor import WebMonitor as _MonitorImpl
    from skyrecorder.console_ui import ConsoleUI as _UI
else:
    from skyrecorder.monitor import SpotifyMonitor as _MonitorImpl
    from skyrecorder.ui import AppUI as _UI

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s  %(levelname)-8s %(name)s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("skyrecorder")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=4455)
    parser.add_argument("--password", default="")
    parser.add_argument("--min-duration", type=float, default=15.0)
    parser.add_argument("--no-mp3", action="store_true",
                        help="disable automatic audio export of recordings")
    parser.add_argument("--no-cover", action="store_true",
                        help="skip cover art embedding in the export")
    parser.add_argument("--format", nargs="+", default=["mp3"],
                        help="export format(s): mp3, wav, flac — can be combined, "
                             "e.g. --format mp3 flac. Default: mp3")
    args = parser.parse_args()

    exporter = AudioExporter(
        log_cb=lambda msg, level: ui.log(msg, level),
        enabled=not args.no_mp3,
        cover=not args.no_cover,
        fmts=args.format,
    )

    obs = OBSController(
        host=args.host, port=args.port, password=args.password,
        min_record_secs=args.min_duration,
        exporter=exporter,
    )

    monitor: _MonitorImpl | None = None
    obs_ok: bool = False

    def connect_obs() -> bool:
        try:
            obs.connect()
            return True
        except OBSError as e:
            logger.warning("OBS unavailable: %s", e)
            return False

    def on_monitor_start():
        nonlocal monitor, obs_ok
        if monitor is not None:
            ui.log("Monitoring already running", "WARNING")
            return

        obs_ok = connect_obs()
        ui.set_obs_status(obs_ok)
        if obs_ok:
            ui.log("Connected to OBS WebSocket")
        else:
            ui.log("OBS unavailable — monitoring without recording", "WARNING")

        ui.log("Monitoring Spotify...")

        wrap_start = _wrap_start(obs, ui) if obs_ok else _noop_start(ui)
        wrap_stop = _wrap_stop(obs, ui) if obs_ok else _noop_stop(ui)

        def on_track(artist: str, title: str) -> None:
            ui.set_song(artist, title)
            obs.set_track(artist, title)

        import inspect
        kwargs: dict = dict(
            on_song_start=wrap_start,
            on_stop=wrap_stop,
            on_track=on_track,
            log_cb=lambda msg, level: ui.log(msg, level),
        )
        if obs_ok and "on_pause" in inspect.signature(_MonitorImpl.__init__).parameters:
            kwargs["on_pause"] = lambda: obs.pause_recording()
            kwargs["on_resume"] = lambda: obs.resume_recording()
        m = _MonitorImpl(**kwargs)
        m.start()
        monitor = m

    def on_monitor_stop():
        nonlocal monitor, obs_ok
        if monitor is not None:
            monitor.disconnect()
            monitor = None
        if obs_ok:
            try:
                obs.stop_recording()
            except Exception as e:
                logger.warning("Stop: stop_recording error: %s", e)
        ui.set_obs_status(False)
        ui.set_recording(False)
        ui.clear_song()

    def on_shutdown():
        nonlocal monitor, obs_ok
        if monitor is not None:
            logger.info("Shutdown: disconnecting monitor")
            monitor.disconnect()
            monitor = None
        if obs_ok:
            logger.info("Shutdown: stopping OBS recording")
            try:
                obs.stop_recording()
            except Exception as e:
                logger.warning("Shutdown: stop_recording error: %s", e)
        exporter.shutdown()
        obs.disconnect()
        logger.info("Shutdown complete")

    def on_key_change(key: str) -> None:
        import json
        from skyrecorder.audio_export import CONFIG_PATH
        try:
            try:
                with open(CONFIG_PATH) as f:
                    cfg = json.load(f)
            except Exception:
                cfg = {}
            cfg["acoustid_api_key"] = (key or "").strip()
            with open(CONFIG_PATH, "w") as f:
                json.dump(cfg, f, indent=2)
        except Exception as e:
            logger.warning("Cannot save AcoustID key: %s", e)
            return
        exporter.reload_key()

    ui = _UI(
        on_start=on_monitor_start,
        on_stop=on_monitor_stop,
        on_shutdown=on_shutdown,
        auto_start=True,
        initial_formats=args.format,
        on_format_change=lambda fmts: exporter.set_formats(fmts),
        on_key_change=on_key_change,
    )
    ui.set_acoustid(exporter._acoustid_key)
    ready, status_msg = exporter.status()
    logger.info("%s", status_msg)
    ui.log(status_msg, "INFO" if ready else "WARNING")
    ui.run()


def _wrap_start(obs: OBSController, ui: _UI):
    def cb():
        try:
            obs.start_recording()
        except OBSError:
            ui.log("OBS recording failed", "ERROR")
            return
        ui.set_recording(True)
    return cb


def _wrap_stop(obs: OBSController, ui: _UI):
    def cb():
        try:
            obs.stop_recording()
        except OBSError:
            return
        ui.set_recording(False)
    return cb


def _noop_start(ui: _UI):
    def cb():
        ui.set_recording(True)
    return cb


def _noop_stop(ui: _UI):
    def cb():
        ui.set_recording(False)
    return cb


if __name__ == "__main__":
    main()
