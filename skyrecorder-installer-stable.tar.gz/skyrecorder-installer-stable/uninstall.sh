#!/usr/bin/env bash
# SkyRecorder uninstaller
set -euo pipefail

APP_NAME="skyrecorder"
INSTALL_DIR="${HOME}/.local/share/${APP_NAME}"
BIN_DIR="${HOME}/.local/bin"
APP_DIR="${HOME}/.local/share/applications"
ICON_DIR="${HOME}/.local/share/icons/hicolor/scalable/apps"

echo "Uninstalling SkyRecorder..."

# Launcher
if [ -f "${BIN_DIR}/${APP_NAME}" ]; then
    rm -f "${BIN_DIR}/${APP_NAME}"
    echo "  removed launcher"
fi

# Desktop entry
if [ -f "${APP_DIR}/${APP_NAME}.desktop" ]; then
    rm -f "${APP_DIR}/${APP_NAME}.desktop"
    echo "  removed desktop entry"
    command -v update-desktop-database >/dev/null 2>&1 \
        && update-desktop-database "${APP_DIR}" 2>/dev/null || true
fi

# Desktop shortcut
DESKTOP_DIR="${HOME}/Desktop"
if [ -f "${HOME}/.config/user-dirs.dirs" ]; then
    XDG_DESKTOP=$(sed -n 's/^XDG_DESKTOP_DIR="\(.*\)"$/\1/p' "${HOME}/.config/user-dirs.dirs" | head -n1)
    if [ -n "${XDG_DESKTOP}" ]; then
        DESKTOP_DIR="${XDG_DESKTOP/\$HOME/${HOME}}"
    fi
fi
if [ -f "${DESKTOP_DIR}/${APP_NAME}.desktop" ]; then
    rm -f "${DESKTOP_DIR}/${APP_NAME}.desktop"
    echo "  removed desktop shortcut"
fi

# Icon
if [ -f "${ICON_DIR}/${APP_NAME}.svg" ]; then
    rm -f "${ICON_DIR}/${APP_NAME}.svg"
    echo "  removed icon"
fi

# App + venv
if [ -d "${INSTALL_DIR}" ]; then
    rm -rf "${INSTALL_DIR}"
    echo "  removed ${INSTALL_DIR}"
fi

echo "SkyRecorder uninstalled."
echo "Note: system packages (python3-gobject/gtk4/libadwaita) and OBS Studio were left installed."
