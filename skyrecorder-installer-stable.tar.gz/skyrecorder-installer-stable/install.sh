#!/usr/bin/env bash
# SkyRecorder installer for Fedora / Bazzite (rpm-ostree) and Debian/Ubuntu (apt)
set -euo pipefail

APP_NAME="skyrecorder"
INSTALL_DIR="${HOME}/.local/share/${APP_NAME}"
BIN_DIR="${HOME}/.local/bin"
APP_DIR="${HOME}/.local/share/applications"
ICON_DIR="${HOME}/.local/share/icons/hicolor/scalable/apps"
VENV="${INSTALL_DIR}/venv"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; }

echo "============================================"
echo "       SkyRecorder Installer"
echo "============================================"
echo

# ---- 1. Python check ----
if ! command -v python3 >/dev/null 2>&1; then
    err "python3 not found. Install Python 3.10+ first."
    exit 1
fi

PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
PY_OK=$(python3 -c 'import sys; print(1 if sys.version_info >= (3,10) else 0)')
if [ "$PY_OK" != "1" ]; then
    err "Python $PY_VER found, but 3.10+ is required."
    exit 1
fi
ok "Python $PY_VER"

# ---- 2. Detect package manager / OS ----
PKG_MGR="unknown"
if command -v rpm-ostree >/dev/null 2>&1; then
    PKG_MGR="rpm-ostree"   # Bazzite / Fedora Atomic
elif command -v dnf >/dev/null 2>&1; then
    PKG_MGR="dnf"          # Fedora / RHEL
elif command -v apt >/dev/null 2>&1; then
    PKG_MGR="apt"          # Debian / Ubuntu / Zorin
fi
ok "Package manager: ${PKG_MGR}"

# ---- 3. Check / install system dependencies ----
# PyGObject (gi) + GTK4 + libadwaita are system-level; the venv uses
# --system-site-packages so it can see them without pip-installing.
check_gi() {
    python3 -c 'import gi; gi.require_version("Gtk","4.0"); gi.require_version("Adw","1"); from gi.repository import Gtk, Adw, GLib, Gio' 2>/dev/null
}

if check_gi; then
    ok "PyGObject + GTK4 + libadwaita already available"
else
    warn "PyGObject / GTK4 / libadwaita missing — attempting install"
    case "$PKG_MGR" in
        rpm-ostree)
            warn "Bazzite is immutable. Installing via rpm-ostree (a reboot will be required)."
            sudo rpm-ostree install \
                python3-gobject gtk4 libadwaita \
                || { err "rpm-ostree install failed"; exit 1; }
            echo
            warn "Reboot required before continuing. Run this installer again after reboot."
            exit 0
            ;;
        dnf)
            sudo dnf install -y \
                python3-gobject gtk4 libadwaita \
                || { err "dnf install failed"; exit 1; }
            ;;
        apt)
            sudo apt-get update -qq
            sudo apt-get install -y \
                python3-gi python3-gi-cairo gir1.2-gtk-4.0 gir1.2-adw-1 \
                || { err "apt install failed"; exit 1; }
            ;;
        *)
            err "Unknown package manager. Install python3-gobject, gtk4 and libadwaita manually."
            exit 1
            ;;
    esac
    ok "System dependencies installed"
fi

# ---- 4. ffmpeg + audio export stack ----
# ffprobe: recording-duration checks; ffmpeg+libmp3lame: MP3 export
# (WAV/FLAC need no extra encoder, they are in every ffmpeg build)
if ! command -v ffprobe >/dev/null 2>&1 || ! command -v ffmpeg >/dev/null 2>&1; then
    warn "ffmpeg not found — installing"
    case "$PKG_MGR" in
        rpm-ostree) sudo rpm-ostree install ffmpeg || warn "ffmpeg install skipped" ;;
        dnf)        sudo dnf install -y ffmpeg || warn "ffmpeg install skipped" ;;
        apt)        sudo apt-get install -y ffmpeg || warn "ffmpeg install skipped" ;;
    esac
fi

if command -v ffmpeg >/dev/null 2>&1; then
    # no -q here: grep must drain the pipe or ffmpeg gets SIGPIPE and
    # pipefail turns a match into a failure
    if ffmpeg -hide_banner -encoders 2>&1 | grep -w libmp3lame >/dev/null; then
        ok "ffmpeg with libmp3lame ready (max quality VBR MP3 export)"
    else
        warn "ffmpeg lacks libmp3lame — MP3 export will be disabled"
    fi
fi

# Chromaprint (fpcalc) — optional; enables AcoustID fingerprint matching,
# the most accurate metadata tier. MusicBrainz name search works without it.
# Fedora/RHEL package is "chromaprint-tools" (Debian/Ubuntu: libchromaprint-tools).
if ! command -v fpcalc >/dev/null 2>&1; then
    if [ "$PKG_MGR" = "rpm-ostree" ] && rpm-ostree status 2>/dev/null | grep -q "chromaprint-tools"; then
        warn "chromaprint-tools already staged — reboot to activate fpcalc"
    else
        warn "fpcalc not found — installing chromaprint tools (optional)"
        case "$PKG_MGR" in
            rpm-ostree) sudo rpm-ostree install chromaprint-tools \
                            || warn "chromaprint install skipped (optional feature disabled)" ;;
            dnf)        sudo dnf install -y chromaprint-tools \
                            || warn "chromaprint install skipped (optional feature disabled)" ;;
            apt)        sudo apt-get install -y libchromaprint-tools \
                            || warn "chromaprint install skipped (optional feature disabled)" ;;
        esac
    fi
fi
if command -v fpcalc >/dev/null 2>&1; then
    ok "Chromaprint ready (fpcalc — AcoustID fingerprint matching)"
else
    warn "fpcalc not available — fingerprint matching disabled (name search still works)"
    if [ "$PKG_MGR" = "rpm-ostree" ]; then
        warn "On Bazzite, reboot activates fpcalc if the layer above succeeded"
    fi
fi

# ---- 5. OBS Studio ----
obs_installed() {
    command -v obs >/dev/null 2>&1 && return 0
    command -v flatpak >/dev/null 2>&1 && flatpak info com.obsproject.Studio >/dev/null 2>&1 && return 0
    return 1
}

install_obs_flatpak() {
    command -v flatpak >/dev/null 2>&1 || return 1
    flatpak remote-add --if-not-exists flathub \
        https://dl.flathub.org/repo/flathub.flatpakrepo 2>/dev/null || \
        sudo flatpak remote-add --if-not-exists flathub \
        https://dl.flathub.org/repo/flathub.flatpakrepo 2>/dev/null || return 1
    flatpak install -y flathub com.obsproject.Studio \
        || sudo flatpak install -y flathub com.obsproject.Studio
}

if obs_installed; then
    ok "OBS Studio already installed"
else
    warn "OBS Studio not found — installing"
    case "$PKG_MGR" in
        rpm-ostree)
            # Flatpak preferred on immutable systems (no reboot needed)
            if install_obs_flatpak; then
                ok "OBS Studio installed (Flatpak, no reboot needed)"
            else
                sudo rpm-ostree install obs-studio \
                    || { err "OBS install failed"; exit 1; }
                warn "OBS installed via rpm-ostree — reboot required after this installer finishes"
            fi
            ;;
        dnf)
            if sudo dnf install -y obs-studio 2>/dev/null; then
                ok "OBS Studio installed (rpm)"
            elif install_obs_flatpak; then
                ok "OBS Studio installed (Flatpak)"
            else
                err "OBS Studio install failed"
                exit 1
            fi
            ;;
        apt)
            sudo apt-get update -qq
            if sudo apt-get install -y obs-studio 2>/dev/null; then
                ok "OBS Studio installed (rpm/deb)"
            elif install_obs_flatpak; then
                ok "OBS Studio installed (Flatpak)"
            else
                err "OBS Studio install failed"
                exit 1
            fi
            ;;
    esac
fi

# ---- 6. Ensure venv module works ----
if ! python3 -c 'import venv, ensurepip' 2>/dev/null; then
    warn "python3 venv/ensurepip missing — installing"
    case "$PKG_MGR" in
        rpm-ostree) sudo rpm-ostree install python3 "python3-pip" || true ;;
        dnf)        sudo dnf install -y python3 "python3-pip" || true ;;
        apt)
            PY_MM=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
            sudo apt-get update -qq
            sudo apt-get install -y "python3-${PY_MM}-venv" python3-pip \
                || { err "Failed to install python3-venv"; exit 1; }
            ;;
    esac
    python3 -c 'import venv, ensurepip' 2>/dev/null \
        || { err "venv module still unavailable"; exit 1; }
    ok "venv module ready"
fi

# ---- 7. Copy application files ----
mkdir -p "${INSTALL_DIR}"
rm -rf "${INSTALL_DIR}/skyrecorder"
cp -r "${SRC_DIR}/skyrecorder" "${INSTALL_DIR}/"
# never ship bytecode built by another interpreter
rm -rf "${INSTALL_DIR}/skyrecorder/__pycache__"
cp "${SRC_DIR}/main.py" "${INSTALL_DIR}/"
cp "${SRC_DIR}/requirements.txt" "${INSTALL_DIR}/"
# MP3 export config (kept on reinstall if user already added an API key)
if [ ! -f "${INSTALL_DIR}/skyrecorder_config.json" ]; then
    cat > "${INSTALL_DIR}/skyrecorder_config.json" <<'EOF'
{
  "acoustid_api_key": ""
}
EOF
fi
ok "Application files -> ${INSTALL_DIR}"

# ---- 8. Virtualenv (system-site-packages so gi works) ----
# PYTHONNOUSERSITE=1 forces pip to install INTO the venv, even if the
# package already exists in ~/.local (user site). gi still resolves
# because system-site-packages is enabled.
if [ ! -x "${VENV}/bin/pip" ]; then
    rm -rf "${VENV}"
    python3 -m venv --system-site-packages "${VENV}" \
        || { err "Failed to create virtualenv"; exit 1; }
fi
PYTHONNOUSERSITE=1 "${VENV}/bin/pip" install --quiet --upgrade pip
PYTHONNOUSERSITE=1 "${VENV}/bin/pip" install --quiet -r "${INSTALL_DIR}/requirements.txt"
ok "Virtualenv ready -> ${VENV}"

# ---- 9. Launcher script ----
mkdir -p "${BIN_DIR}"
cat > "${BIN_DIR}/${APP_NAME}" <<EOF
#!/usr/bin/env bash
# Terminal launch -> output on screen; desktop launch -> appended to last-run.log
LOG="${INSTALL_DIR}/last-run.log"
if [ -t 1 ]; then
    exec "${VENV}/bin/python" "${INSTALL_DIR}/main.py" "\$@"
else
    exec "${VENV}/bin/python" "${INSTALL_DIR}/main.py" "\$@" >>"\$LOG" 2>&1
fi
EOF
chmod +x "${BIN_DIR}/${APP_NAME}"
ok "Launcher -> ${BIN_DIR}/${APP_NAME}"

# Warn if ~/bin not on PATH
case ":${PATH}:" in
    *":${BIN_DIR}:"*) ;;
    *) warn "${BIN_DIR} is not on your PATH. Add this to ~/.bashrc:  export PATH=\"\$HOME/.local/bin:\$PATH\"" ;;
esac

# ---- 10. Icon ----
mkdir -p "${ICON_DIR}"
if [ -f "${SRC_DIR}/icons/skyrecorder.svg" ]; then
    cp "${SRC_DIR}/icons/skyrecorder.svg" "${ICON_DIR}/${APP_NAME}.svg"
elif [ -f "${HOME}/.local/share/icons/skyrecorder.svg" ]; then
    cp "${HOME}/.local/share/icons/skyrecorder.svg" "${ICON_DIR}/${APP_NAME}.svg"
fi
ok "Icon -> ${ICON_DIR}/${APP_NAME}.svg"

# ---- 11. Desktop entry ----
mkdir -p "${APP_DIR}"
cat > "${APP_DIR}/${APP_NAME}.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=SkyRecorder
Comment=Auto-record OBS when Spotify plays a song, skip ads
Exec=${BIN_DIR}/${APP_NAME}
Icon=${APP_NAME}
Terminal=false
Categories=Audio;Video;
EOF
chmod 644 "${APP_DIR}/${APP_NAME}.desktop"
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "${APP_DIR}" 2>/dev/null || true
fi
ok "Desktop entry -> ${APP_DIR}/${APP_NAME}.desktop"

# ---- 12. Desktop shortcut (icon on the desktop) ----
# Resolve XDG desktop dir, fall back to ~/Desktop
DESKTOP_DIR="${HOME}/Desktop"
if [ -f "${HOME}/.config/user-dirs.dirs" ]; then
    XDG_DESKTOP=$(sed -n 's/^XDG_DESKTOP_DIR="\(.*\)"$/\1/p' "${HOME}/.config/user-dirs.dirs" | head -n1)
    if [ -n "${XDG_DESKTOP}" ]; then
        DESKTOP_DIR="${XDG_DESKTOP/\$HOME/${HOME}}"
    fi
fi
mkdir -p "${DESKTOP_DIR}"
cat > "${DESKTOP_DIR}/${APP_NAME}.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=SkyRecorder
Comment=Auto-record OBS when Spotify plays a song, skip ads
Exec=${BIN_DIR}/${APP_NAME}
Icon=${APP_NAME}
Terminal=false
Categories=Audio;Video;
EOF
chmod 755 "${DESKTOP_DIR}/${APP_NAME}.desktop"
# Mark as trusted so GNOME shows it without "Untrusted" prompt
if command -v gio >/dev/null 2>&1; then
    gio set "${DESKTOP_DIR}/${APP_NAME}.desktop" "metadata::trusted" true 2>/dev/null || true
fi
ok "Desktop shortcut -> ${DESKTOP_DIR}/${APP_NAME}.desktop"

# ---- 13. Verify ----
echo
echo "============================================"
echo "            Verifying install"
echo "============================================"
if "${VENV}/bin/python" -c 'import obsws_python' 2>/dev/null; then
    OBSPATH=$("${VENV}/bin/python" -c 'import obsws_python,os;print(os.path.dirname(obsws_python.__file__))')
    case "$OBSPATH" in
        "${VENV}"/*) ok "obsws-python installed in venv" ;;
        *)           warn "obsws-python resolved outside venv (${OBSPATH})" ;;
    esac
else
    err "obsws-python failed to import"
fi
if "${VENV}/bin/python" -c 'import gi; gi.require_version("Gtk","4.0")' 2>/dev/null; then
    ok "GTK4 / PyGObject importable"
else
    warn "GTK4 / PyGObject not importable yet (reboot may be needed on Bazzite)"
fi
if obs_installed; then
    ok "OBS Studio available"
else
    warn "OBS Studio not found"
fi
if command -v ffmpeg >/dev/null 2>&1 && ffmpeg -hide_banner -encoders 2>&1 | grep -w libmp3lame >/dev/null; then
    ok "Audio export ready (MP3 VBR q0 / WAV / FLAC, metadata, cover art)"
else
    warn "Audio export unavailable (ffmpeg/libmp3lame missing)"
fi
if command -v fpcalc >/dev/null 2>&1; then
    ok "AcoustID fingerprint matching available"
else
    warn "fpcalc not found — AcoustID fingerprint matching disabled (optional)"
fi

echo
echo "============================================"
echo "          Installation complete!"
echo "============================================"
echo " Run:        skyrecorder"
echo " Or find:    SkyRecorder in your app menu"
echo " Uninstall:  ./uninstall.sh"
echo
echo " One manual step (first run):"
echo "   1. Open OBS Studio"
echo "   2. Tools -> WebSocket Server Settings"
echo "   3. Enable the server, set a password"
echo "   4. Launch:  skyrecorder --password <your-password>"
echo
echo " Audio export: each finished recording is exported next to the video"
echo "   file. Formats are chosen in the app (multi-select) or via CLI:"
echo "     MP3  = VBR q0 (LAME -q:a 0, up to 320 kbps) + tags + cover art"
echo "     WAV  = PCM 24-bit, lossless, no tags/cover"
echo "     FLAC = lossless + tags + cover art"
echo "   Combine them:  skyrecorder --format mp3 flac"
echo

# ---- 14. AcoustID setup (interactive, skipped if not a terminal) ----
if [ -t 0 ]; then
    echo "============================================"
    echo "            AcoustID setup (optional)"
    echo "============================================"
    echo " AcoustID fingerprinting identifies the EXACT recording,"
    echo " so you always get the right cover art and tags."
    echo " Get a free API key at:  https://acoustid.org/new-application"
    echo
    printf " Enter your AcoustID API key (or press Enter to skip): "
    read -r ACOUSTID_KEY || ACOUSTID_KEY=""
    if [ -n "${ACOUSTID_KEY}" ]; then
        python3 - "${INSTALL_DIR}/skyrecorder_config.json" "${ACOUSTID_KEY}" <<'PYEOF'
import json, sys
path, key = sys.argv[1], sys.argv[2].strip()
try:
    with open(path) as f:
        cfg = json.load(f)
except Exception:
    cfg = {}
cfg["acoustid_api_key"] = key
with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
print("saved")
PYEOF
        ok "AcoustID API key saved — exact fingerprint matching enabled"
    else
        warn "Skipped — add it later via ${INSTALL_DIR}/skyrecorder_config.json"
    fi
    echo
else
    echo " Optional: for exact fingerprint-based tagging, get a free API key at"
    echo "   https://acoustid.org/new-application and put it in"
    echo "   ${INSTALL_DIR}/skyrecorder_config.json -> \"acoustid_api_key\""
    echo
fi
