#!/usr/bin/env bash
#==============================================================================
#  SkyRecorder — Installateur graphique
#  Aucune commande requise : double-cliquez et suivez les écrans.
#  (zenity pour GNOME/Ubuntu, kdialog pour KDE/Bazzite)
#==============================================================================
set -uo pipefail

APP_NAME="skyrecorder"
INSTALL_DIR="${HOME}/.local/share/${APP_NAME}"
BIN_DIR="${HOME}/.local/bin"
APP_DIR="${HOME}/.local/share/applications"
ICON_DIR="${HOME}/.local/share/icons/hicolor/scalable/apps"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="${INSTALL_DIR}/venv"

# ---------------------------------------------------------------------------
#  Backend GUI
# ---------------------------------------------------------------------------
GUI=""
if command -v zenity >/dev/null 2>&1; then
    GUI="zenity"
elif command -v kdialog >/dev/null 2>&1; then
    GUI="kdialog"
fi

gui_info() {
    case "$GUI" in
        zenity) zenity --info --title="SkyRecorder" --width=420 --text="$1" >/dev/null ;;
        kdialog) kdialog --msgbox "$1" --title "SkyRecorder" >/dev/null ;;
    esac
}

gui_error() {
    case "$GUI" in
        zenity) zenity --error --title="SkyRecorder" --width=420 --text="$1" >/dev/null ;;
        kdialog) kdialog --error "$1" --title "SkyRecorder" >/dev/null ;;
    esac
}

gui_question() {                                             # 0 = Oui
    case "$GUI" in
        zenity) zenity --question --title="SkyRecorder" --width=420 --text="$1" \
                        --ok-label="Oui" --cancel-label="Non" >/dev/null ;;
        kdialog) kdialog --yesno "$1" --title "SkyRecorder" >/dev/null ;;
    esac
}

gui_log() {                                                  # affiche un log
    case "$GUI" in
        zenity) zenity --text-info --title="SkyRecorder — Détails" --width=600 --height=400 \
                        --filename="$1" >/dev/null ;;
        kdialog) kdialog --textbox "$1" 600 400 --title "SkyRecorder — Détails" >/dev/null ;;
    esac
}

gui_entry() {                                                # saisie texte, affiche le resultat
    case "$GUI" in
        zenity) zenity --entry --title="SkyRecorder" --width=420 --text="$1" ;;
        kdialog) kdialog --inputbox "$1" --title "SkyRecorder" ;;
    esac
}

# ---------------------------------------------------------------------------
#  Exécution en root via pkexec (boîte de dialogue polkit native, pas de terminal)
# ---------------------------------------------------------------------------
run_root() {
    if command -v pkexec >/dev/null 2>&1; then
        pkexec "$@"
        return $?
    fi
    local askpass
    askpass="$(mktemp /tmp/sr-askpass.XXXXXX.sh)"
    {
        echo '#!/bin/sh'
        if command -v kdialog >/dev/null 2>&1; then
            echo 'kdialog --password "SkyRecorder — droits administrateur requis :"'
        elif command -v zenity >/dev/null 2>&1; then
            echo 'zenity --password --title="SkyRecorder"'
        else
            echo 'exit 1'
        fi
    } > "$askpass"
    chmod +x "$askpass"
    SUDO_ASKPASS="$askpass" sudo -A "$@"
    local rc=$?
    rm -f "$askpass"
    return $rc
}

# ---------------------------------------------------------------------------
#  Étapes
# ---------------------------------------------------------------------------
step_python() {
    command -v python3 >/dev/null 2>&1 || { echo "python3 est introuvable."; return 1; }
    python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' \
        || { echo "Python 3.10 ou plus récent est requis."; return 1; }
}

detect_pkg_mgr() {
    if command -v rpm-ostree >/dev/null 2>&1; then PKG_MGR="rpm-ostree"
    elif command -v dnf >/dev/null 2>&1;       then PKG_MGR="dnf"
    elif command -v apt >/dev/null 2>&1;        then PKG_MGR="apt"
    else PKG_MGR="unknown"; fi
}

check_deps() {
    python3 -c 'import gi; gi.require_version("Gtk","4.0"); gi.require_version("Adw","1"); from gi.repository import Gtk, Adw' 2>/dev/null
}

install_deps() {
    if check_deps; then
        return 0
    fi
    case "$PKG_MGR" in
        rpm-ostree) run_root rpm-ostree install python3-gobject gtk4 libadwaita ;;
        dnf)        run_root dnf install -y python3-gobject gtk4 libadwaita ;;
        apt)
            run_root apt-get update -qq
            run_root apt-get install -y python3-gi python3-gi-cairo gir1.2-gtk-4.0 gir1.2-adw-1
            ;;
        *) echo "Gestionnaire de paquets inconnu."; return 1 ;;
    esac
}

install_ffmpeg() {
    command -v ffmpeg >/dev/null 2>&1 && return 0
    case "$PKG_MGR" in
        rpm-ostree) run_root rpm-ostree install ffmpeg ;;
        dnf)        run_root dnf install -y ffmpeg ;;
        apt)        run_root apt-get install -y ffmpeg ;;
        *) return 1 ;;
    esac
}

install_obs_flatpak() {
    command -v flatpak >/dev/null 2>&1 || return 1
    flatpak remote-add --if-not-exists flathub \
        https://dl.flathub.org/repo/flathub.flatpakrepo >/dev/null 2>&1 || true
    flatpak install -y flathub com.obsproject.Studio >/dev/null 2>&1
}

install_obs() {
    if command -v obs >/dev/null 2>&1; then
        return 0
    fi
    if command -v flatpak >/dev/null 2>&1 && flatpak info com.obsproject.Studio >/dev/null 2>&1; then
        return 0
    fi
    if install_obs_flatpak; then
        return 0
    fi
    case "$PKG_MGR" in
        rpm-ostree) run_root rpm-ostree install obs-studio ;;
        dnf)        run_root dnf install -y obs-studio ;;
        apt)        run_root apt-get install -y obs-studio ;;
        *) return 1 ;;
    esac
}

setup_venv() {
    mkdir -p "${INSTALL_DIR}"
    if [ ! -x "${VENV}/bin/pip" ]; then
        rm -rf "${VENV}"
        python3 -m venv --system-site-packages "${VENV}" || return 1
    fi
    PYTHONNOUSERSITE=1 "${VENV}/bin/pip" install --quiet --upgrade pip || return 1
    PYTHONNOUSERSITE=1 "${VENV}/bin/pip" install --quiet -r "${SRC_DIR}/requirements.txt" || return 1
}

copy_files() {
    rm -rf "${INSTALL_DIR}/skyrecorder"
    cp -r "${SRC_DIR}/skyrecorder" "${INSTALL_DIR}/" || return 1
    rm -rf "${INSTALL_DIR}/skyrecorder/__pycache__"
    cp "${SRC_DIR}/main.py" "${INSTALL_DIR}/" || return 1
    cp "${SRC_DIR}/requirements.txt" "${INSTALL_DIR}/" || return 1
    if [ ! -f "${INSTALL_DIR}/skyrecorder_config.json" ]; then
        printf '{\n  "acoustid_api_key": ""\n}\n' > "${INSTALL_DIR}/skyrecorder_config.json"
    fi
}

create_shortcuts() {
    mkdir -p "${BIN_DIR}" "${APP_DIR}" "${ICON_DIR}"

    cat > "${BIN_DIR}/${APP_NAME}" <<EOF
#!/usr/bin/env bash
LOG="${INSTALL_DIR}/last-run.log"
if [ -t 1 ]; then
    exec "${VENV}/bin/python" "${INSTALL_DIR}/main.py" "\$@"
else
    exec "${VENV}/bin/python" "${INSTALL_DIR}/main.py" "\$@" >>"\$LOG" 2>&1
fi
EOF
    chmod +x "${BIN_DIR}/${APP_NAME}"

    [ -f "${SRC_DIR}/icons/skyrecorder.svg" ] && \
        cp "${SRC_DIR}/icons/skyrecorder.svg" "${ICON_DIR}/${APP_NAME}.svg"

    cat > "${APP_DIR}/${APP_NAME}.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=SkyRecorder
Comment=Auto-record OBS when Spotify plays a song, skip ads
Exec=${BIN_DIR}/${APP_NAME}
Icon=${APP_NAME}
Terminal=false
Categories=Audio;Video;
EOF
    chmod 644 "${APP_DIR}/${APP_NAME}.desktop"
    command -v update-desktop-database >/dev/null 2>&1 && \
        update-desktop-database "${APP_DIR}" >/dev/null 2>&1 || true

    # Raccourci sur le bureau
    local desktop_dir="${HOME}/Desktop"
    if [ -f "${HOME}/.config/user-dirs.dirs" ]; then
        local xdg
        xdg=$(sed -n 's/^XDG_DESKTOP_DIR="\(.*\)"$/\1/p' "${HOME}/.config/user-dirs.dirs" | head -n1)
        if [ -n "$xdg" ]; then
            desktop_dir="${xdg/\$HOME/${HOME}}"
        fi
    fi
    mkdir -p "$desktop_dir"
    cp "${APP_DIR}/${APP_NAME}.desktop" "${desktop_dir}/${APP_NAME}.desktop"
    chmod 755 "${desktop_dir}/${APP_NAME}.desktop"
    command -v gio >/dev/null 2>&1 && \
        gio set "${desktop_dir}/${APP_NAME}.desktop" "metadata::trusted" true >/dev/null 2>&1 || true
}

# ---------------------------------------------------------------------------
#  Installation principale (avec barre de progression)
# ---------------------------------------------------------------------------
do_install() {
    local log
    (
        echo "5";   echo "# Vérification de Python..."
        step_python 2>>"$LOG_FILE" || exit 1

        echo "15";  echo "# Détection du système..."
        detect_pkg_mgr

        echo "25";  echo "# Dépendances système (GTK4, libadwaita)..."
        install_deps 2>>"$LOG_FILE" || exit 1

        echo "40";  echo "# ffmpeg..."
        install_ffmpeg 2>>"$LOG_FILE" || true

        echo "55";  echo "# OBS Studio..."
        install_obs 2>>"$LOG_FILE" || true

        echo "70";  echo "# Environnement Python..."
        setup_venv 2>>"$LOG_FILE" || exit 1

        echo "85";  echo "# Fichiers de l'application..."
        copy_files 2>>"$LOG_FILE" || exit 1

        echo "95";  echo "# Raccourcis..."
        create_shortcuts 2>>"$LOG_FILE" || exit 1

        echo "100"
    ) | {
        case "$GUI" in
            zenity) zenity --progress --title="Installation de SkyRecorder" \
                            --text="Installation en cours, veuillez patienter..." \
                            --percentage=0 --auto-close --no-cancel --width=450 >/dev/null 2>&1 ;;
            kdialog) kdialog --progressbar "Installation en cours, veuillez patienter..." 100 >/dev/null 2>&1 ;;
        esac
    }

    local rc=${PIPESTATUS[0]}
    if [ "$rc" -eq 0 ]; then
        rm -f "$LOG_FILE"
    fi
    return $rc
}

# ---------------------------------------------------------------------------
#  Configuration AcoustID (clé API gratuite → identification exacte)
# ---------------------------------------------------------------------------
setup_acoustid() {
    if ! gui_question "Activer la reconnaissance exacte (AcoustID) ?\n\nCela identifie l'enregistrement EXACT par empreinte audio — plus de pochettes erronées.\n\nIl vous faut une clé API GRATUITE (30 secondes) :\nhttps://acoustid.org/new-application"; then
        return 0
    fi
    local key
    key="$(gui_entry "Collez votre clé API AcoustID :" | tr -d ' \t\r\n')"
    if [ -z "$key" ]; then
        return 0
    fi
    python3 - "${INSTALL_DIR}/skyrecorder_config.json" "$key" <<'PYEOF'
import json, sys
path, key = sys.argv[1], sys.argv[2].strip()
try:
    with open(path) as f:
        cfg = json.load(f)
except Exception:
    cfg = {}
cfg["acoustid_api_key"] = key
with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
print("saved")
PYEOF
    gui_info "Clé AcoustID enregistrée !\n\nLa reconnaissance exacte est active."
}

# ---------------------------------------------------------------------------
#  Point d'entrée
# ---------------------------------------------------------------------------
main() {
    if [ -z "$GUI" ]; then
        echo "ERREUR : zenity ou kdialog est requis pour l'installateur graphique."
        echo "Installez l'un d'eux, ou utilisez ./install.sh dans un terminal."
        exit 1
    fi

    gui_info "Bienvenue dans l'installateur de SkyRecorder.\n\nAucune commande n'est requise : cliquez sur « Installer » et suivez les écrans."

    if ! gui_question "Installer SkyRecorder maintenant ?"; then
        gui_info "Installation annulée."
        exit 0
    fi

    if do_install; then
        setup_acoustid
        gui_info "SkyRecorder est installé !\n\nVous le trouverez dans le menu des applications, ou sous forme d'icône sur le bureau.\n\nPour enregistrer : lancez OBS Studio, activez le serveur WebSocket (Outils → Paramètres du serveur WebSocket), puis lancez SkyRecorder.\n\nFonctionnalités :\n• Format d'export MP3 / WAV / FLAC (choisi dans l'app ou --format)"
    else
        gui_error "L'installation a échoué.\n\nLe journal détaillé est affiché ci-dessous."
        gui_log "${LOG_FILE}"
    fi
}

# Fichier de journal conservé en cas d'échec (rempli par do_install)
LOG_FILE="$(mktemp /tmp/sr-install.XXXXXX.log)"
export LOG_FILE

main "$@"
